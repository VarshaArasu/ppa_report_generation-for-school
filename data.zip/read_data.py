
import json
with open('school_info.json', 'r') as file:
    data = json.load(file) 
school_name = data['school_name']
print(f"School Name: {school_name}")