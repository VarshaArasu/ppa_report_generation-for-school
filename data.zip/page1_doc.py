# Empty Word Document
from docx import Document
doc = Document()
doc.save('page1_doc.docx')

#JSON 
import json
with open('data.json', 'r') as file:
    data = json.load(file) 
schoolname = data['schoolname']
programstartdate = data['programstartdate']
numberofstudentsenrolled = data['numberofstudentsenrolled']
noofstudentsdoneppa = data['noofstudentsdoneppa']
gradesconducted = data['gradesconducted']
reportingperiod = data['reportingperiod']
minutestrained = data['minutestrained']
puzzlesattempted = data['puzzlesattempted']
puzzlesolved = data['puzzlesolved']
bspiscorerangeIA_80 = data['bspiscorerangeIA_80']
bspiscorerangeIA_60 = data['bspiscorerangeIA_60']
bspiscorerangeIA_40 = data['bspiscorerangeIA_40']
bspiscorerangeIA_20 = data['bspiscorerangeIA_20']
bspiscorerangeIA_10 = data['bspiscorerangeIA_10']
bspiscorerangePPA_80 = data['bspiscorerangePPA_80']
bspiscorerangePPA_60 = data['bspiscorerangePPA_60']
bspiscorerangePPA_40 = data['bspiscorerangePPA_40']
bspiscorerangePPA_20 = data['bspiscorerangePPA_20']
bspiscorerangePPA_10 = data['bspiscorerangePPA_10']
noofstudIA = data['noofstudIA']
noofstudPPA = data['noofstudPPA']
schoolavgbspi = data['schoolavgbspi']
graphIA1 = data['graphIA1']
graphIA2 = data['graphIA2']
graphIA3 = data['graphIA3']
graphIA4 = data['graphIA4']
graphIA5 = data['graphIA5']
graphIA6 = data['graphIA6']
graphPPA1 = data['graphPPA1']
graphPPA2 = data['graphPPA2']
graphPPA3 = data['graphPPA3']
graphPPA4 = data['graphPPA4']
graphPPA5 = data['graphPPA5']
graphPPA6 = data['graphPPA6']

grade3IA20 = data['grade3IA20']
grade3IA40 = data['grade3IA40']
grade3IA60 = data['grade3IA60']
grade3IA80 = data['grade3IA80']
grade3IA81 = data['grade3IA81']
grade3PPA20 = data['grade3PPA20']
grade3PPA40 = data['grade3PPA40']
grade3PPA60 = data['grade3PPA60']
grade3PPA80 = data['grade3PPA80']
grade3PPA81 = data['grade3PPA81']

grade4IA20 = data['grade4IA20']
grade4IA40 = data['grade4IA40']
grade4IA60 = data['grade4IA60']
grade4IA80 = data['grade4IA80']
grade4IA81 = data['grade4IA81']
grade4PPA20 = data['grade4PPA20']
grade4PPA40 = data['grade4PPA40']
grade4PPA60 = data['grade4PPA60']
grade4PPA80 = data['grade4PPA80']
grade4PPA81 = data['grade4PPA81']

grade5IA20 = data['grade5IA20']
grade5IA40 = data['grade5IA40']
grade5IA60 = data['grade5IA60']
grade5IA80 = data['grade5IA80']
grade5IA81 = data['grade5IA81']
grade5PPA20 = data['grade5PPA20']
grade5PPA40 = data['grade5PPA40']
grade5PPA60 = data['grade5PPA60']
grade5PPA80 = data['grade5PPA80']
grade5PPA81 = data['grade5PPA81']

grade6IA20 = data['grade6IA20']
grade6IA40 = data['grade6IA40']
grade6IA60 = data['grade6IA60']
grade6IA80 = data['grade6IA80']
grade6IA81 = data['grade6IA81']
grade6PPA20 = data['grade6PPA20']
grade6PPA40 = data['grade6PPA40']
grade6PPA60 = data['grade6PPA60']
grade6PPA80 = data['grade6PPA80']
grade6PPA81 = data['grade6PPA81']

grade7IA20 = data['grade7IA20']
grade7IA40 = data['grade7IA40']
grade7IA60 = data['grade7IA60']
grade7IA80 = data['grade7IA80']
grade7IA81 = data['grade7IA81']
grade7PPA20 = data['grade7PPA20']
grade7PPA40 = data['grade7PPA40']
grade7PPA60 = data['grade7PPA60']
grade7PPA80 = data['grade7PPA80']
grade7PPA81 = data['grade7PPA81']

grade8IA20 = data['grade8IA20']
grade8IA40 = data['grade8IA40']
grade8IA60 = data['grade8IA60']
grade8IA80 = data['grade8IA80']
grade8IA81 = data['grade8IA81']
grade8PPA20 = data['grade8PPA20']
grade8PPA40 = data['grade8PPA40']
grade8PPA60 = data['grade8PPA60']
grade8PPA80 = data['grade8PPA80']
grade8PPA81 = data['grade8PPA81']

memoryIA = data['memoryIA']
visualpIA = data['visualpIA']
focusatIA = data['focusatIA']
probsolIA = data['probsolIA']
linguisIA = data['linguisIA']
memoryPPA = data['memoryPPA']
visualpPPA = data['visualpPPA']
focusatPPA = data['focusatPPA']
probsolPPA = data['probsolPPA']
linguisPPA = data['linguisPPA']

memIA20 = data['memIA20']
memIA40 = data['memIA40']
memIA60 = data['memIA60']
memIA80 = data['memIA80']
memIA81 = data['memIA81']
memPPA20 = data['memPPA20']
memPPA40 = data['memPPA40']
memPPA60 = data['memPPA60']
memPPA80 = data['memPPA80']
memPPA81 = data['memPPA81']

memgraIA1 = data['memgraIA1']
memgraIA2 = data['memgraIA2']
memgraIA3 = data['memgraIA3']
memgraIA4 = data['memgraIA4']
memgraIA5 = data['memgraIA5']
memgraPA1 = data['memgraPA1']
memgraPA2 = data['memgraPA2']
memgraPA3 = data['memgraPA3']
memgraPA4 = data['memgraPA4']
memgraPA5 = data['memgraPA5']

vispIA20 = data['vispIA20']
vispIA40 = data['vispIA40']
vispIA60 = data['vispIA60']
vispIA80 = data['vispIA80']
vispIA81 = data['vispIA81']
vispPA20 = data['vispPA20']
vispPA40 = data['vispPA40']
vispPA60 = data['vispPA60']
vispPA80 = data['vispPA80']
vispPA81 = data['vispPA81']

visgraIA1 = data['visgraIA1']
visgraIA2 = data['visgraIA2']
visgraIA3 = data['visgraIA3']
visgraIA4 = data['visgraIA4']
visgraIA5 = data['visgraIA5']
visgraPA1 = data['visgraPA1']
visgraPA2 = data['visgraPA2']
visgraPA3 = data['visgraPA3']
visgraPA4 = data['visgraPA4']
visgraPA5 = data['visgraPA5']

focuatIA1 = data['focuatIA1']
focuatIA2 = data['focuatIA2']
focuatIA3 = data['focuatIA3']
focuatIA4 = data['focuatIA4']
focuatIA5 = data['focuatIA5']
focuatPA1 = data['focuatPA1']
focuatPA2 = data['focuatPA2']
focuatPA3 = data['focuatPA3']
focuatPA4 = data['focuatPA4']
focuatPA5 = data['focuatPA5']

focgraIA1 = data['focgraIA1']
focgraIA2 = data['focgraIA2']
focgraIA3 = data['focgraIA3']
focgraIA4 = data['focgraIA4']
focgraIA5 = data['focgraIA5']
focgraPA1 = data['focgraPA1']
focgraPA2 = data['focgraPA2']
focgraPA3 = data['focgraPA3']
focgraPA4 = data['focgraPA4']
focgraPA5 = data['focgraPA5']

prosolIA1 = data['prosolIA1']
prosolIA2 = data['prosolIA2']
prosolIA3 = data['prosolIA3']
prosolIA4 = data['prosolIA4']
prosolIA5 = data['prosolIA5']
prosolPA1 = data['prosolPA1']
prosolPA2 = data['prosolPA2']
prosolPA3 = data['prosolPA3']
prosolPA4 = data['prosolPA4']
prosolPA5 = data['prosolPA5']

prograIA1 = data['prograIA1']
prograIA2 = data['prograIA2']
prograIA3 = data['prograIA3']
prograIA4 = data['prograIA4']
prograIA5 = data['prograIA5']
prograPA1 = data['prograPA1']
prograPA2 = data['prograPA2']
prograPA3 = data['prograPA3']
prograPA4 = data['prograPA4']
prograPA5 = data['prograPA5']

linguiIA1 = data['linguiIA1']
linguiIA2 = data['linguiIA2']
linguiIA3 = data['linguiIA3']
linguiIA4 = data['linguiIA4']
linguiIA5 = data['linguiIA5']
linguiPA1 = data['linguiPA1']
linguiPA2 = data['linguiPA2']
linguiPA3 = data['linguiPA3']
linguiPA4 = data['linguiPA4']
linguiPA5 = data['linguiPA5']

lingraIA1 = data['lingraIA1']
lingraIA2 = data['lingraIA2']
lingraIA3 = data['lingraIA3']
lingraIA4 = data['lingraIA4']
lingraIA5 = data['lingraIA5']
lingraPA1 = data['lingraPA1']
lingraPA2 = data['lingraPA2']
lingraPA3 = data['lingraPA3']
lingraPA4 = data['lingraPA4']
lingraPA5 = data['lingraPA5']

graph1 = data['graph1']
graph2 = data['graph2']
graph3 = data['graph3']
graph4 = data['graph4']
graph5 = data['graph5']
graph6 = data['graph6']
graph7 = data['graph7']
graph8 = data['graph8']
graph9 = data['graph9']
graph10 = data['graph10']
graph11 = data['graph11']
graph12 = data['graph12']
graph13 = data['graph13']
graph14 = data['graph14']
graph15 = data['graph15']
graph16 = data['graph16']
graph17 = data['graph17']
graph18 = data['graph18']
graph19 = data['graph19']
graph20= data['graph20']
graph21 = data['graph21']

prodigiesname = data['prodigiesname']
prodigiesgrade = data['prodigiesgrade']
prodigiessec = data['prodigiessec']
prodigiesBSPI = data['prodigiesBSPI']

grade3avgscbel8 = data['grade3avgscbel8']
grade4avgscbel8 = data['grade4avgscbel8']
grade5avgscbel8 = data['grade5avgscbel8']
grade6avgscbel8 = data['grade6avgscbel8']
grade7avgscbel8 = data['grade7avgscbel8']
grade8avgscbel8 = data['grade8avgscbel8']
grade3avgsabove8 = data['grade3avgsabove8']
grade4avgsabove8 = data['grade4avgsabove8']
grade5avgsabove8 = data['grade5avgsabove8']
grade6avgsabove8 = data['grade6avgsabove8']
grade7avgsabove8 = data['grade7avgsabove8']
grade8avgsabove8 = data['grade8avgsabove8']

FAstud1 = data['FAstud1']
FAgrade1 = data['FAgrade1']
FAsec1 = data['FAsec1']
FAppa_bspi = data['FAppa_bspi']

gstars_stud1 = data['gstars_stud1']
gstars_grade1 = data['gstars_grade1']
gstars_sec1 = data['gstars_sec1']
gstars_ppabspi1 = data['gstars_ppabspi1']

#First page
from docx import Document
from docx.shared import Inches
from docx.shared import Cm
doc = Document('page1_doc.docx')
section = doc.sections[0]
header = section.header
for paragraph in header.paragraphs:
    for run in paragraph.runs:
        run.clear() 
section.different_first_page_header_footer = False
left_margin = section.left_margin
right_margin = section.right_margin
page_width = section.page_width - left_margin - right_margin
page_height = section.page_height
image_path = 'firstpage.png' 
doc.add_picture(image_path, width=page_width, height=page_height)
doc.save('page1_doc.docx')
print("First page added")

#Adding header
from docx import Document
from docx.shared import Inches
from docx.shared import Cm
doc = Document('page1_doc.docx')
section = doc.sections[0]
section.header_distance = Cm(0)  
left_margin = section.left_margin
right_margin = section.right_margin
width = section.page_width - left_margin - right_margin
header = section.header
paragraph = header.paragraphs[0]
run = paragraph.add_run()  
run.add_picture('header.png', width=width)  
doc.save('page1_doc.docx')
print("Header added")

# Text Insertion and Centre allignment
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt  
doc = Document('page1_doc.docx')  
para = doc.add_paragraph(' Contents')
para.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = para.runs[0]   
run.bold = True  
run.font.size = Pt(14)  
doc.save('page1_doc.docx')  


# Table creation 
from docx import Document
from docx.shared import Pt
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
data = [
    ["1", "The Impact of SKILLANGELS 2023-2024", "3"],
    ["1.1", "Aligning SKILLANGELS with other academic records", "4"],
    ["2", "Program Overview", "4"],
    ["2.1", "Skill Progression & Brain Skill Power Index (BSPI) comparison", "6"],
    ["2.2", "How they performed over the year", "7"],
    ["3", "A high-level overview of Assessment results", "8"],
    ["3.1", "BSPI comparison across grades", "8"],
    ["3.2", "BSPI improvement for each Grade", "9"],
    ["3.3", "Highly gifted students", "10"],
    ["3.4", "Future Achievers", "10"],
    ["3.5", "Growing Stars", "12"],
    ["4", "Skill Performance – Initial Vs. Post Program Assessment", "13"],
    ["5", "Do you know how well they did?", "19"],
    ["6", "Sub-Skill Score Analysis", "20"],
    ["7", "Achievers in PPA 2023-24", "21"],
    ["7.1", "BSPI Toppers by Grade & Section", "2.2"],
    ["7.2", "Skill Toppers by Grade & Section", "23"],
    ["8", "Final Inference", "26"],
    ["9", "Next level considerations", "26"],
    ["10", "Other Links", "27"]
]
doc = Document('page1_doc.docx')
table = doc.add_table(rows=21, cols=3)
hdr_cells = table.rows[0].cells
hdr_cells[0].text = 'Sl No'
hdr_cells[1].text = 'Details'
hdr_cells[2].text = 'Page No'
for cell in hdr_cells:
    paragraph = cell.paragraphs[0]
    run = paragraph.runs[0]
    run.bold = True
    run.font.size = Pt(12)
for row in range(1, 21):  
    row_cells = table.rows[row].cells
    if row - 1 < len(data):  
        row_cells[0].text = data[row - 1][0]  
        row_cells[1].text = data[row - 1][1]  
        row_cells[2].text = data[row - 1][2]  #
    else:
        row_cells[0].text = "N/A"
        row_cells[1].text = "N/A"
        row_cells[2].text = "N/A"
for row in table.rows:
    row.cells[0].width = Pt(70)
    row.cells[1].width = Pt(380)
    row.cells[2].width = Pt(70)
for row in table.rows:
    for cell in row.cells:
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                run.font.size = Pt(12)
def set_borders(table):
    for row in table.rows:
        for cell in row.cells:
            cell_xml = cell._element
            tc_pr = cell_xml.find(qn('w:tcPr'))
            if tc_pr is None:
                tc_pr = OxmlElement('w:tcPr')
                cell_xml.append(tc_pr)
            borders = OxmlElement('w:tcBorders')
            for side in ['top', 'left', 'bottom', 'right']:
                border = OxmlElement(f'w:{side}')
                border.set(qn('w:val'), 'single')  
                border.set(qn('w:space'), '0')
                border.set(qn('w:sz'), '4')  # Border size
                borders.append(border)
            tc_pr.append(borders)
set_borders(table)
doc.save('page1_doc.docx')  
print("Table created")

# PAGE 2
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph('Annual Performance Report 2023-24')
para.alignment = WD_ALIGN_PARAGRAPH.CENTER  
run = para.runs[0]
run.bold = True
run.font.size = Pt(18)  
run.font.color.rgb = RGBColor(0, 112, 192)  
para = doc.add_paragraph('1. The Impact of SKILLANGELS')
run = para.runs[0]
run.font.size = Pt(14) 
run.font.color.rgb = RGBColor(45, 116, 181)

para = doc.add_paragraph('The academic year 2023-24 has been challenging in many respects, '
                          'with schools trying to find the right blend of skill-building and concept progression '
                          'at every stage and grade. EDSIX BRAINLAB has strengthened the efforts of ')
run = para.add_run(schoolname)
run.bold = True  
para.add_run(' by getting students on the SKILLANGELS platform to perform at their cognitive best. ')
para = doc.add_paragraph('Before the details of this impact are shared, we are happy to present the most relevant '
             'and essential findings of your students.')
for run in para.runs:
    run.font.size = Pt(12) 
doc.save('page1_doc.docx')

#LOGO INSERTION
from docx import Document
from docx.shared import Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
doc = Document('page1_doc.docx')  
para = doc.add_paragraph()
run = para.add_run()
logo_path = r'C:\Users\varsh\OneDrive\Sathyabama\Edsix\New folder\logo_image.png'  
run.add_picture(logo_path, width=Inches(2)) 
para.alignment = WD_ALIGN_PARAGRAPH.CENTER
doc.save('page1_doc.docx')  
print("Logo inserted")

#Next para
from docx import Document
from docx.shared import Pt
doc = Document('page1_doc.docx')
para = doc.add_paragraph('These critical data points highlight the impact that SKILLANGELS has had on the students at ')  
run = para.add_run(schoolname)
run.bold = True  
para.add_run('.')
run = para.add_run('This data has also highlighted the following:')
for run in para.runs:
    run.font.size = Pt(12) 
doc.save('page1_doc.docx')
print("Text, images are inserted successfully")

#Box Creation
from docx import Document
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.enum.text import WD_ALIGN_PARAGRAPH
import docx
doc = Document('page1_doc.docx')
table = doc.add_table(rows=1, cols=1)
cell = table.cell(0, 0)
points = ["Performance is interrelated with continuous student-engagement.",
          "Students can climb the Cognitive Ladder effectively & steadily.",
          "Progression in multiple skillsets is evident and measurable."
]
for point in points:
    para = cell.add_paragraph(point, style='List Bullet')  
    para.alignment = WD_ALIGN_PARAGRAPH.LEFT
    para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    para.style.font.size = Pt(12)
cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER  # Horizontal center
cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER 
for row in table.rows:
    for cell in row.cells:
        cell_xml = cell._element
        tc_pr = cell_xml.get_or_add_tcPr()
        borders = docx.oxml.OxmlElement('w:tcBorders')
        for border_name in ['top', 'left', 'bottom', 'right']:
            border = docx.oxml.OxmlElement(f'w:{border_name}')
            border.set(qn('w:val'), 'single')  # Solid line
            border.set(qn('w:sz'), '6')  
            border.set(qn('w:space'), '0')  
            border.set(qn('w:color'), 'FFA500')  
            borders.append(border)
        tc_pr.append(borders)
table.alignment = WD_ALIGN_PARAGRAPH.CENTER  
doc.save('page1_doc.docx')
print("Table created")

#Next Para
from docx import Document
from docx.shared import Pt
doc = Document('page1_doc.docx')
para = doc.add_paragraph()
para = doc.add_paragraph("Edsix team is proud to present this evidence-based report, which will pave way for further understanding and use of cognitive skilling that is essential to future-proof today's young learners.")
run = para.runs[0]
run.font.size = Pt(12)
doc.save('page1_doc.docx') 

#PAGE 3
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph('1.1 Aligning SKILLANGELS with other academic records:') 
para.alignment = WD_ALIGN_PARAGRAPH.LEFT
run = para.runs[0]
run.font.size = Pt(14) 
run.font.color.rgb = RGBColor(45, 116, 181)
para = doc.add_paragraph('While highlighting the impact of this program, it would be relevant to note that Cognitive Upskilling gains a high level of attention and importance in the context of the current CBSE curriculum. The shift towards the Competency-based Learning & Assessment model that has been advocated by the')
run = para.add_run(' New Education Policy')
run.bold = True  
para.add_run('and the CBSE ensures that every child is given the support and the opportunity to enhance')
run = para.add_run(' Higher Order Thinking Skills')
run.bold = True
para.add_run(', thereby working towards competency and mastery in a subject. All teaching and learning efforts are outcome-based, leading to the need for a program that can be evidence for measurable achievements. With this program and quantifiable results, there is a clear indication of the continuum that every child moves on to help multiple stakeholders keep track at every stage.')
para = doc.add_paragraph("The SKILLANGELS CAUP scaffolds the learning process by providing an engaging and supportive platform in the learning cycle. For this precise reason, the data generated in this report should be viewed along with other academic records to get a comprehensive view of the student's achievements.")
para = doc.add_paragraph('Important terms in this report')
run = para.runs[0]
run.bold = True
for run in para.runs:
    run.font.size = Pt(12) 
doc.save('page1_doc.docx') 

#Table
from docx import Document
from docx.shared import Inches, Pt
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
doc = Document('page1_doc.docx')
table = doc.add_table(rows=3, cols=2)
table.cell(0, 0).text = 'CAUP'
table.cell(0, 1).text = 'COGNITIVE ABILITIES UPSKILLING PROGRAM'
table.cell(1, 0).text = 'IA & PPA'
table.cell(1, 1).text = 'Initial Assessment & Post Program Assessment'
table.cell(2, 0).text = 'BSPI'
table.cell(2, 1).text = 'BRAIN SKILL POWER INDEX- An average measure of Cognitive Brain Skills across 5 core areas: Memory, Visual Processing, Focus & Attention, Problem Solving, and Linguistics'
for row in table.rows:
    row.cells[0].paragraphs[0].runs[0].bold = True
for column in table.columns:
    for cell in column.cells:
        cell.width = Inches(4) 
for row in table.rows:
    row.cells[0].width = Pt(70)  
    row.cells[1].width = Pt(350)
for row in table.rows:
    for cell in row.cells:
        cell_xml = cell._element
        tc_pr = cell_xml.get_or_add_tcPr()
        borders = OxmlElement('w:tcBorders')
        for border_name in ['top', 'left', 'bottom', 'right']:
            border = OxmlElement(f'w:{border_name}')
            border.set(qn('w:val'), 'single') 
            border.set(qn('w:sz'), '4') 
            border.set(qn('w:space'), '0')  
            border.set(qn('w:color'), '000000')  #Black color
            borders.append(border)
        tc_pr.append(borders)
doc.save("page1_doc.docx") 
print("Table inserted")

#
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph('2.Program Overview')
run = para.runs[0]
run.bold = True
run.font.size = Pt(14)
run.font.color.rgb = RGBColor(45, 116, 181)
doc.save('page1_doc.docx')

#Table Creation
from docx import Document
from docx.shared import Inches, Pt
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
doc = Document('page1_doc.docx')
table = doc.add_table(rows=6, cols=2)
table.cell(0, 0).text = 'Program name:'
table.cell(0, 1).text = 'SKILLANGELS – COGNITIVE ABILITIES UPSKILLING PROGRAM'
table.cell(1, 0).text = 'Program Start Date:'
table.cell(1, 1).text =  programstartdate
table.cell(2, 0).text = 'Number of students enrolled'
table.cell(2, 1).text =  numberofstudentsenrolled
table.cell(3, 0).text = 'Number of students who have completed the PPA'
table.cell(3, 1).text =  noofstudentsdoneppa
table.cell(4, 0).text = 'Grades in which the program has been conducted'
table.cell(4, 1).text =  gradesconducted
table.cell(5, 0).text = 'Reporting Period:'
table.cell(5, 1).text =  reportingperiod
for column in table.columns:
    for cell in column.cells:
        cell.width = Inches(4) 
for row in table.rows:
    row.cells[0].width = Pt(350)  
    row.cells[1].width = Pt(250)
for row in table.rows:
    for cell in row.cells:
        cell_xml = cell._element
        tc_pr = cell_xml.get_or_add_tcPr()
        borders = OxmlElement('w:tcBorders')
        for border_name in ['top', 'left', 'bottom', 'right']:
            border = OxmlElement(f'w:{border_name}')
            border.set(qn('w:val'), 'single') 
            border.set(qn('w:sz'), '4') 
            border.set(qn('w:space'), '0')  
            border.set(qn('w:color'), '000000')  #Black color
            borders.append(border)
        tc_pr.append(borders)
column_color = 'FFE499'  
for row in range(6):
    cell = table.cell(row, 0)  
    cell_xml = cell._element
    tc_pr = cell_xml.get_or_add_tcPr()
    shading = OxmlElement('w:shd')
    shading.set(qn('w:fill'), column_color)
    tc_pr.append(shading)
doc.save("page1_doc.docx") 
print("Table created")

#PAGE 4
from docx import Document
from docx.shared import Pt
doc = Document('page1_doc.docx')
para = doc.add_paragraph()
para = doc.add_paragraph('At EDSIX BRAINLAB we work to help children develop cognitive skills and become 21st century learners. We take pride in our collaboration with ')  
run = para.add_run(schoolname)
run.bold = True  
para.add_run(',')
run = para.add_run(' marking a significant endeavor. This aims to contribute to academic excellence and community engagement.')
para = doc.add_paragraph('')
run = para.add_run('Initial Assessment')
run.bold = True
para.add_run(' (IA) was conducted in June 2023 to establish the baseline of the student’s skill level at the start of the ')
run = para.add_run('SKILLANGELS - COGNITIVE ABILITIES UPSKILLING PROGRAM (CAUP). Post-Program Assessment')
run.bold = True
para.add_run('(PPA) was conducted at the end of the school year in March 2024. The progress of every learner is tracked right through the program and the progress can be observed on the Admin Portal.')
para = doc.add_paragraph('')
run = para.add_run('(PPA) was conducted at the end of the school year in March 2024. The progress of every learner is tracked right through the program and the progress can be observed on the Admin Portal.')
run.bold = True
for run in para.runs:
    run.font.size = Pt(12) 
doc.save('page1_doc.docx') 

#LOGO
from docx import Document
from docx.shared import Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
doc = Document('page1_doc.docx')  
para = doc.add_paragraph()
run = para.add_run()
logo_path = r'C:\Users\varsh\OneDrive\Sathyabama\Edsix\New folder\logo2.png'  
run.add_picture(logo_path, width=Inches(7)) 
para.alignment = WD_ALIGN_PARAGRAPH.CENTER
doc.save('page1_doc.docx')   
print("Logo inserted")

#Table
from docx import Document
from docx.shared import Inches
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
doc = Document('page1_doc.docx')
para = doc.add_paragraph()
table = doc.add_table(rows=2, cols=3)
table.cell(0, 0).text = 'Minutes Trained'
table.cell(0, 1).text = 'Puzzles Attempted'
table.cell(0, 2).text = 'Puzzles Solved'
table.cell(1, 0).text =  minutestrained
table.cell(1, 1).text =  puzzlesattempted
table.cell(1, 2).text =  puzzlesolved
table.autofit = False  
col_width = Inches(2.0) 
for column in table.columns:
    for cell in column.cells:
        cell.width = col_width
for row in table.rows:
    for cell in row.cells:
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                run.bold = True
                run.font.size = Pt(14)
colors = ['D99594','FABC8F', 'C2D69B']  
for col_index, column in enumerate(table.columns):
    for cell in column.cells:
        cell_xml = cell._element
        shading = OxmlElement('w:shd')
        shading.set(qn('w:fill'), colors[col_index])  
        cell_xml.get_or_add_tcPr().append(shading) 
for row in table.rows:
    for cell in row.cells:
        cell_xml = cell._element
        tc_pr = cell_xml.get_or_add_tcPr()
        borders = OxmlElement('w:tcBorders')
        for border_name in ['top', 'left', 'bottom', 'right']:
            border = OxmlElement(f'w:{border_name}')
            border.set(qn('w:val'), 'single')  
            border.set(qn('w:sz'), '4') 
            border.set(qn('w:space'), '0')  
            border.set(qn('w:color'), '000000')  
            borders.append(border)
        tc_pr.append(borders)
doc.save("page1_doc.docx") 
print("Table inserted")

#Next topic (PAGE 4)
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph('2.1 Skill Progression & Brain Skill Power Index (BSPI) Comparison')
run = para.runs[0]
run.bold = True 
run.font.size = Pt(14)
run.font.color.rgb = RGBColor(45, 116, 181)
doc.save('page1_doc.docx')

# Table
from docx import Document
from docx.shared import Inches, Pt
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
doc = Document('page1_doc.docx')
table = doc.add_table(rows=7, cols=4)
table.cell(0, 0).text = 'BSPI Score Range'
table.cell(0, 1).text = 'Description'
table.cell(0, 2).text = 'Number of students in IA'
table.cell(0, 3).text = 'Number of students in PPA'
table.cell(1, 0).text = '> 80'
table.cell(1, 1).text = 'Prodigy! This is fantastic. Keep it up and take it further!'
table.cell(1, 2).text =  bspiscorerangeIA_80
table.cell(1, 3).text =  bspiscorerangePPA_80
table.cell(2, 0).text = '> 60 and <= 80'
table.cell(2, 1).text = 'You have a spark. A little more determination and you will be there!'
table.cell(2, 2).text = bspiscorerangeIA_60 
table.cell(2, 3).text = bspiscorerangePPA_60
table.cell(3, 0).text = '> 40 and <= 60 '
table.cell(3, 1).text = 'The intervention will enhance academic performance. A slight push is all that is needed!'
table.cell(3, 2).text = bspiscorerangeIA_40
table.cell(3, 3).text = bspiscorerangePPA_40
table.cell(4, 0).text = ' > 20 and <= 40'
table.cell(4, 1).text = 'Needs Immediate Intervention. You can surely do it! Mistakes are the steppingstones to success.'
table.cell(4, 2).text = bspiscorerangeIA_20
table.cell(4, 3).text = bspiscorerangePPA_20
table.cell(5, 0).text = ' <= 20 '
table.cell(5, 1).text = "Rigorous and immediate intervention is needed. But don't feel low – You can certainly improve!"
table.cell(5, 2).text = bspiscorerangeIA_10
table.cell(5, 3).text = bspiscorerangePPA_10
table.cell(6, 0).text = ' '
table.cell(6, 1).text = 'Number of students who have completed the Program'
table.cell(6, 2).text = noofstudIA
table.cell(6, 3).text = noofstudIA
for column in table.columns:
    for cell in column.cells:
        cell.width = Inches(4) 
for row in [0, 6]:  #First and last row gets bolded.
    for cell in table.rows[row].cells:
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                run.bold = True
                run.font.size = Pt(12)
for row in table.rows:
    row.cells[0].width = Pt(100)  
    row.cells[1].width = Pt(250)
    row.cells[2].width = Pt(100)
    row.cells[3].width = Pt(100)
for row in table.rows:
    for cell in row.cells:
        cell_xml = cell._element
        tc_pr = cell_xml.get_or_add_tcPr()
        borders = OxmlElement('w:tcBorders')
        for border_name in ['top', 'left', 'bottom', 'right']:
            border = OxmlElement(f'w:{border_name}')
            border.set(qn('w:val'), 'single') 
            border.set(qn('w:sz'), '4') 
            border.set(qn('w:space'), '0')  
            border.set(qn('w:color'), '000000')  #Black colour
            borders.append(border)
        tc_pr.append(borders)
row_colors = ['9ACC58', 'FDC850', 'FAA717', 'EB795F', 'EE4646']  
for i in range(1, 6):  
    for cell in table.rows[i].cells:
        cell_xml = cell._element
        tc_pr = cell_xml.get_or_add_tcPr()
        shading = OxmlElement('w:shd')
        shading.set(qn('w:fill'), row_colors[i-1]) 
        tc_pr.append(shading)
doc.save("page1_doc.docx") 
print("Table inserted")

# 
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph("The remarkable improvement observed in students' performance is evident. Initially, 114 students, representing 35% of the total, were classified in the top bands of BSPI during the initial assessment. However, this figure rose to 234 students, accounting for 71% of the total, in the post-assessment phase. This substantial increase suggests a notable enhancement in students' abilities over the course of the assessment period.")
run = para.runs[0]
run.font.size = Pt(12)
doc.save('page1_doc.docx') 

#
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph('We congratulate the students and teachers on this excellent performance.')
para.alignment = WD_ALIGN_PARAGRAPH.CENTER  
run = para.runs[0]
run.bold = True  
run.font.size = Pt(14)  
run.font.color.rgb = RGBColor(0, 112, 192)  
doc.save('page1_doc.docx') 

#logo
from docx import Document
from docx.shared import Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
doc = Document('page1_doc.docx')  
para = doc.add_paragraph()
run = para.add_run()
logo_path = r'C:\Users\varsh\OneDrive\Sathyabama\Edsix\New folder\logo_image.png'  
run.add_picture(logo_path, width=Inches(1)) 
para.alignment = WD_ALIGN_PARAGRAPH.CENTER
doc.save('page1_doc.docx')   

#Next page
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph()
para = doc.add_paragraph('2.2 How they performed over the year.')
run = para.runs[0]
run.bold = True
run.font.size = Pt(14)
run.font.color.rgb = RGBColor(45, 116, 181)
doc.save('page1_doc.docx')

#
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph('The overall school average BSPI has increased from ')  
run = para.add_run( schoolavgbspi)
run.bold = True  
run.font.color.rgb = RGBColor(0, 175, 80)
para.add_run('.')
para = doc.add_paragraph('Continuous tracking of student engagement and performance has shown that every student who consistently uses the platform is able to move ahead steadily and achieve significantly higher scores from the beginning to the end of the program.')
para = doc.add_paragraph("In expressing gratitude for the teachers' commendable efforts in this academic year, we encourage sustained and uplifting support for every student to actively participate and engage with the program. This would definitively show positive results not just in cognitive skill building but in academic performance as well.")
for run in para.runs:
    run.font.size = Pt(12) 
doc.save('page1_doc.docx') 
print("Text inserted")

#logo
from docx import Document
from docx.shared import Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
doc = Document('page1_doc.docx')  
para = doc.add_paragraph()
run = para.add_run()
logo_path = r'C:\Users\varsh\OneDrive\Sathyabama\Edsix\New folder\logo_image.png'  
run.add_picture(logo_path, width=Inches(2)) 
para.alignment = WD_ALIGN_PARAGRAPH.CENTER
doc.save('page1_doc.docx')   

#topic
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph('3 A high-level overview of Assessment results  3.1 BSPI comparison across grades: ')
run = para.runs[0]
run.bold = True
run.font.size = Pt(14)
run.font.color.rgb = RGBColor(45, 116, 181)
doc.save('page1_doc.docx')

# next para
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph('Since the ')  
run = para.add_run('IA')
run.bold = True  
para.add_run(',students have improved in their overall skill proficiency on average, which is indicated in the table below. Students who have completed fewer than eight sessions were not considered for this analysis since they would not have had enough practice to make a meaningful comparison.')
para = doc.add_paragraph('Over the course of the academic year, noticeable improvement in the average BSPI has been evident across ALL grades from the beginning to the end. ')
for run in para.runs:
    run.font.size = Pt(12) 
doc.save('page1_doc.docx') 

#GRAPH INSERTION
import matplotlib.pyplot as plt
import numpy as np
from docx import Document
from docx.shared import Inches
import io
def rgb_to_normalized(rgb):
    return tuple([x / 255.0 for x in rgb])
background_color = rgb_to_normalized((32, 56, 100))  
bar1_color = rgb_to_normalized((154, 87, 205))  
bar2_color = rgb_to_normalized((146, 208, 80)) 
items = ['III', 'IV', 'V', 'VI', 'VII', 'VIII']
initial_scores = [graphIA1, graphIA2, graphIA3, graphIA4, graphIA5, graphIA6]  
post_scores = [graphPPA1, graphPPA2, graphPPA3, graphPPA4, graphPPA5, graphPPA6]   
x = np.arange(len(items))  
width = 0.25  
fig, ax = plt.subplots(figsize=(9, 5))
plt.gcf().set_facecolor(background_color)  
ax.set_facecolor(background_color) 
gap = 0.02
bar1 = ax.bar(x - width/2 - gap, initial_scores, width, label='Initial Assessment', color=bar1_color)  
bar2 = ax.bar(x + width/2 + gap, post_scores, width, label='Post Program Assessment', color=bar2_color) 
ax.set_title('BSPI growth-Initial vs Post Program Assessment', color='white')  
ax.set_xticks(x)
ax.set_xticklabels(items, color='white') 
ax.tick_params(axis='y', colors='white')  
ax.tick_params(axis='x', colors='white')  
ax.legend(facecolor='gray', edgecolor='white', loc='upper right', fontsize=10, framealpha=0.7)  
for i, rect in enumerate(bar1):
    height = rect.get_height()
    ax.text(rect.get_x() + rect.get_width() / 2, height, str(initial_scores[i]), ha='center', va='bottom', color='white')
for i, rect in enumerate(bar2):
    height = rect.get_height()
    ax.text(rect.get_x() + rect.get_width() / 2, height, str(post_scores[i]), ha='center', va='bottom', color='white')
ax.grid(True, which='both', axis='y' , linestyle='-', color='black', linewidth=0.6, alpha=0.2)
plt.tight_layout()
img_stream = io.BytesIO()
plt.savefig(img_stream, format='png')
img_stream.seek(0) 
doc = Document('page1_doc.docx')  
table = doc.add_table(rows=1, cols=1)
cell = table.cell(0, 0)
cell.paragraphs[0].clear()  
cell.paragraphs[0].add_run().add_picture(img_stream, width=Inches(6)) 
cell.alignment = 1  
doc.save('page1_doc.docx')
img_stream.close() 
print("Graph inserted")

#next para
from docx import Document
from docx.shared import Pt
doc = Document('page1_doc.docx')
para = doc.add_paragraph("The visible improvement from initial assessment to post program assessment indicates a positive impact of the CAUP training, demonstrating its effectiveness in enhancing students' skill sets.")
para = doc.add_paragraph('This positive trend underscores the collective progress and proficiency development observed across various aspects of learning. Congratulations!')
for run in para.runs:
    run.font.size = Pt(12) 
doc.save('page1_doc.docx') 

# topic
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph('3.2 BSPI improvement for each grade:')
run = para.runs[0]
run.bold = True
run.font.size = Pt(14)
run.font.color.rgb = RGBColor(45, 116, 181)
doc.save('page1_doc.docx')

#logo3 insertion
from docx import Document
from docx.shared import Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
doc = Document('page1_doc.docx')  
para = doc.add_paragraph()
run = para.add_run()
logo_path = r'C:\Users\varsh\OneDrive\Sathyabama\Edsix\New folder\logo3.png'  
run.add_picture(logo_path, width=Inches(6)) 
para.alignment = WD_ALIGN_PARAGRAPH.CENTER
doc.save('page1_doc.docx')   
print("Logo inserted")

#Next para
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph('The data below shows the BSPI improvement for each grade.')
para = doc.add_paragraph('This report is analyzed based on the number of students who have taken both the ')  
run = para.add_run('IA')
run.bold = True
para.add_run(' as well as the ')
run = para.add_run('PPA.')
run.bold = True  
para = doc.add_paragraph('The total number of students who have taken both is ')
run = para.add_run( noofstudIA)
run.bold = True
para.add_run('.(as on')
run = para.add_run(reportingperiod)
run.bold = True
para.add_run(').')
for run in para.runs:
    run.font.size = Pt(12) 
doc.save('page1_doc.docx') 

#Table
from docx import Document
from docx.shared import RGBColor, Pt
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
doc = Document('page1_doc.docx')
table = doc.add_table(rows=3, cols=6)
table.cell(0, 0).text = 'Grade III '
table.cell(0, 1).text = '<= 20'
table.cell(0, 2).text = '21-40 '
table.cell(0, 3).text = '41-60 '
table.cell(0, 4).text = '61-80 '
table.cell(0, 5).text = '> 80 '
table.cell(1, 0).text = 'Initial Assessment '
table.cell(1, 1).text =  grade3IA20
table.cell(1, 2).text =  grade3IA40
table.cell(1, 3).text =  grade3IA60
table.cell(1, 4).text =  grade3IA80
table.cell(1, 5).text =  grade3IA81
table.cell(2, 0).text = 'Post Program Assessment'
table.cell(2, 1).text =  grade3PPA20
table.cell(2, 2).text =  grade3PPA40
table.cell(2, 3).text =  grade3PPA60
table.cell(2, 4).text =  grade3PPA80
table.cell(2, 5).text =  grade3PPA81
for row in [0, 2]:  
    cell = table.cell(row, 0)
    for paragraph in cell.paragraphs:
        for run in paragraph.runs:
            run.bold = True
for row in table.rows:
    row.cells[0].width = Pt(150)  # First column narrow
    row.cells[1].width = Pt(60)  # Middle column wide
    row.cells[2].width = Pt(60)
    row.cells[3].width = Pt(60)
    row.cells[4].width = Pt(60)
    row.cells[5].width = Pt(60)
background_colors = [
    RGBColor(238, 70, 70),   # Red
    RGBColor(235, 121, 96),  # Orange
    RGBColor(250, 172, 23),  # Yellow
    RGBColor(253, 194, 80),  # Light Yellow
    RGBColor(154, 204, 88)   # Green
]

def rgb_to_hex(rgb_color):
    return f'{rgb_color[0]:02X}{rgb_color[1]:02X}{rgb_color[2]:02X}'
for col_idx in range(1, 6):  
    cell = table.cell(0, col_idx)
    cell_text = cell.text
    cell.text = ""
    run = cell.paragraphs[0].add_run(cell_text)
    hex_color = rgb_to_hex(background_colors[col_idx - 1])
    cell._element.get_or_add_tcPr().append(
        OxmlElement('w:shd', {qn('w:fill'): hex_color})
    )
def set_cell_borders(cell):
    cell_xml = cell._element
    tc_pr = cell_xml.get_or_add_tcPr()
    borders = OxmlElement('w:tcBorders')
    for border_name in ['top', 'left', 'bottom', 'right']:
        border = OxmlElement(f'w:{border_name}')
        border.set(qn('w:val'), 'single')  # Single border
        border.set(qn('w:sz'), '4')  # Border width
        border.set(qn('w:space'), '0')  # Space between borders
        border.set(qn('w:color'), '000000')  # Black color for borders
        borders.append(border)
    tc_pr.append(borders)
for row in table.rows:
    for cell in row.cells:
        set_cell_borders(cell)
doc.save('page1_doc.docx') 
print("Table inserted")

#Table2
from docx import Document
from docx.shared import RGBColor, Pt
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
doc = Document('page1_doc.docx')
para = doc.add_paragraph()
table = doc.add_table(rows=3, cols=6)
table.cell(0, 0).text = 'Grade IV '
table.cell(0, 1).text = '<= 20'
table.cell(0, 2).text = '21-40 '
table.cell(0, 3).text = '41-60 '
table.cell(0, 4).text = '61-80 '
table.cell(0, 5).text = '> 80 '
table.cell(1, 0).text = 'Initial Assessment '
table.cell(1, 1).text = grade4IA20
table.cell(1, 2).text = grade4IA40
table.cell(1, 3).text = grade4IA60
table.cell(1, 4).text = grade4IA80
table.cell(1, 5).text = grade4IA81
table.cell(2, 0).text = 'Post Program Assessment'
table.cell(2, 1).text = grade4PPA20
table.cell(2, 2).text = grade4PPA40
table.cell(2, 3).text = grade4PPA60
table.cell(2, 4).text = grade4PPA80
table.cell(2, 5).text = grade4PPA81
for row in [0, 2]:  
    cell = table.cell(row, 0)
    for paragraph in cell.paragraphs:
        for run in paragraph.runs:
            run.bold = True
for row in table.rows:
    row.cells[0].width = Pt(150)  # First column narrow
    row.cells[1].width = Pt(60)  # Middle column wide
    row.cells[2].width = Pt(60)
    row.cells[3].width = Pt(60)
    row.cells[4].width = Pt(60)
    row.cells[5].width = Pt(60)
for col_idx in range(6):  
    cell = table.cell(2, col_idx)  
    for paragraph in cell.paragraphs:
        for run in paragraph.runs:
            run.bold = True
background_colors = [
    RGBColor(238, 70, 70),   # Red
    RGBColor(235, 121, 96),  # Orange
    RGBColor(250, 172, 23),  # Yellow
    RGBColor(253, 194, 80),  # Light Yellow
    RGBColor(154, 204, 88)   # Green
]
def rgb_to_hex(rgb_color):
    return f'{rgb_color[0]:02X}{rgb_color[1]:02X}{rgb_color[2]:02X}'
for col_idx in range(1, 6):  
    cell = table.cell(0, col_idx)
    cell_text = cell.text
    cell.text = ""
    run = cell.paragraphs[0].add_run(cell_text)
    hex_color = rgb_to_hex(background_colors[col_idx - 1])
    cell._element.get_or_add_tcPr().append(
        OxmlElement('w:shd', {qn('w:fill'): hex_color})
    )
def set_cell_borders(cell):
    cell_xml = cell._element
    tc_pr = cell_xml.get_or_add_tcPr()
    borders = OxmlElement('w:tcBorders')
    for border_name in ['top', 'left', 'bottom', 'right']:
        border = OxmlElement(f'w:{border_name}')
        border.set(qn('w:val'), 'single')  # Single border
        border.set(qn('w:sz'), '4')  # Border width
        border.set(qn('w:space'), '0')  # Space between borders
        border.set(qn('w:color'), '000000')  # Black color for borders
        borders.append(border)
    tc_pr.append(borders)
for row in table.rows:
    for cell in row.cells:
        set_cell_borders(cell)
doc.save('page1_doc.docx') 
print("Table inserted")

#Table3
from docx import Document
from docx.shared import RGBColor, Pt
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
doc = Document('page1_doc.docx')
para = doc.add_paragraph()
table = doc.add_table(rows=3, cols=6)
table.cell(0, 0).text = 'Grade V'
table.cell(0, 1).text = '<= 20'
table.cell(0, 2).text = '21-40 '
table.cell(0, 3).text = '41-60 '
table.cell(0, 4).text = '61-80 '
table.cell(0, 5).text = '> 80 '
table.cell(1, 0).text = 'Initial Assessment'
table.cell(1, 1).text = grade5IA20
table.cell(1, 2).text = grade5IA40
table.cell(1, 3).text = grade5IA60
table.cell(1, 4).text = grade5IA80
table.cell(1, 5).text = grade5IA81
table.cell(2, 0).text = 'Post Program Assessment'
table.cell(2, 1).text = grade5PPA20
table.cell(2, 2).text = grade5PPA40
table.cell(2, 3).text = grade5PPA60
table.cell(2, 4).text = grade5PPA80
table.cell(2, 5).text = grade5PPA81
for row in [0, 2]:  
    cell = table.cell(row, 0)
    for paragraph in cell.paragraphs:
        for run in paragraph.runs:
            run.bold = True
for row in table.rows:
    row.cells[0].width = Pt(150)  
    row.cells[1].width = Pt(60)  
    row.cells[2].width = Pt(60)
    row.cells[3].width = Pt(60)
    row.cells[4].width = Pt(60)
    row.cells[5].width = Pt(60)
for col_idx in range(6): 
    cell = table.cell(2, col_idx)  
    for paragraph in cell.paragraphs:
        for run in paragraph.runs:
            run.bold = True
background_colors = [
    RGBColor(238, 70, 70),   # Red
    RGBColor(235, 121, 96),  # Orange
    RGBColor(250, 172, 23),  # Yellow
    RGBColor(253, 194, 80),  # Light Yellow
    RGBColor(154, 204, 88)   # Green
]
def rgb_to_hex(rgb_color):
    return f'{rgb_color[0]:02X}{rgb_color[1]:02X}{rgb_color[2]:02X}'
for col_idx in range(1, 6):  
    cell = table.cell(0, col_idx)
    cell_text = cell.text
    cell.text = ""
    run = cell.paragraphs[0].add_run(cell_text)
    hex_color = rgb_to_hex(background_colors[col_idx - 1])
    cell._element.get_or_add_tcPr().append(
        OxmlElement('w:shd', {qn('w:fill'): hex_color})
    )
def set_cell_borders(cell):
    cell_xml = cell._element
    tc_pr = cell_xml.get_or_add_tcPr()
    borders = OxmlElement('w:tcBorders')
    for border_name in ['top', 'left', 'bottom', 'right']:
        border = OxmlElement(f'w:{border_name}')
        border.set(qn('w:val'), 'single')  
        border.set(qn('w:sz'), '4') 
        border.set(qn('w:space'), '0')  
        border.set(qn('w:color'), '000000') 
        borders.append(border)
    tc_pr.append(borders)
for row in table.rows:
    for cell in row.cells:
        set_cell_borders(cell)
doc.save('page1_doc.docx') 
print("Table inserted")

#Table 4
from docx import Document
from docx.shared import RGBColor, Pt
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
doc = Document('page1_doc.docx')
para = doc.add_paragraph()
table = doc.add_table(rows=3, cols=6)
table.cell(0, 0).text = 'Grade VI'
table.cell(0, 1).text = '<= 20'
table.cell(0, 2).text = '21-40'
table.cell(0, 3).text = '41-60'
table.cell(0, 4).text = '61-80'
table.cell(0, 5).text = '> 80'
table.cell(1, 0).text = 'Initial Assessment '
table.cell(1, 1).text = grade6IA20
table.cell(1, 2).text = grade6IA40
table.cell(1, 3).text = grade6IA60
table.cell(1, 4).text = grade6IA80
table.cell(1, 5).text = grade6IA81
table.cell(2, 0).text = 'Post Program Assessment'
table.cell(2, 1).text = grade6PPA20
table.cell(2, 2).text = grade6PPA40
table.cell(2, 3).text = grade6PPA60
table.cell(2, 4).text = grade6PPA80
table.cell(2, 5).text = grade6PPA81
for row in [0, 2]:  
    cell = table.cell(row, 0)
    for paragraph in cell.paragraphs:
        for run in paragraph.runs:
            run.bold = True
for row in table.rows:
    row.cells[0].width = Pt(150) 
    row.cells[1].width = Pt(60)  
    row.cells[2].width = Pt(60)
    row.cells[3].width = Pt(60)
    row.cells[4].width = Pt(60)
    row.cells[5].width = Pt(60)
for col_idx in range(6): 
    cell = table.cell(2, col_idx)  
    for paragraph in cell.paragraphs:
        for run in paragraph.runs:
            run.bold = True
background_colors = [
    RGBColor(238, 70, 70),   # Red
    RGBColor(235, 121, 96),  # Orange
    RGBColor(250, 172, 23),  # Yellow
    RGBColor(253, 194, 80),  # Light Yellow
    RGBColor(154, 204, 88)   # Green
]
def rgb_to_hex(rgb_color):
    return f'{rgb_color[0]:02X}{rgb_color[1]:02X}{rgb_color[2]:02X}'
for col_idx in range(1, 6):  
    cell = table.cell(0, col_idx)
    cell_text = cell.text
    cell.text = ""
    run = cell.paragraphs[0].add_run(cell_text)
    hex_color = rgb_to_hex(background_colors[col_idx - 1])
    cell._element.get_or_add_tcPr().append(
        OxmlElement('w:shd', {qn('w:fill'): hex_color})
    )
def set_cell_borders(cell):
    cell_xml = cell._element
    tc_pr = cell_xml.get_or_add_tcPr()
    borders = OxmlElement('w:tcBorders')
    for border_name in ['top', 'left', 'bottom', 'right']:
        border = OxmlElement(f'w:{border_name}')
        border.set(qn('w:val'), 'single')  
        border.set(qn('w:sz'), '4')  
        border.set(qn('w:space'), '0')  
        border.set(qn('w:color'), '000000')  
        borders.append(border)
    tc_pr.append(borders)
for row in table.rows:
    for cell in row.cells:
        set_cell_borders(cell)
doc.save('page1_doc.docx') 
print("Table inserted")

#
from docx import Document
from docx.shared import RGBColor, Pt
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
doc = Document('page1_doc.docx')
para = doc.add_paragraph()
table = doc.add_table(rows=3, cols=6)
table.cell(0, 0).text = 'Grade VII '
table.cell(0, 1).text = '<= 20'
table.cell(0, 2).text = '21-40 '
table.cell(0, 3).text = '41-60 '
table.cell(0, 4).text = '61-80 '
table.cell(0, 5).text = '> 80 '
table.cell(1, 0).text = 'Initial Assessment'
table.cell(1, 1).text = grade7IA20
table.cell(1, 2).text = grade7IA40
table.cell(1, 3).text = grade7IA60
table.cell(1, 4).text = grade7IA80
table.cell(1, 5).text = grade7IA81
table.cell(2, 0).text = 'Post Program Assessment'
table.cell(2, 1).text = grade7PPA20
table.cell(2, 2).text = grade7PPA40
table.cell(2, 3).text = grade7PPA60
table.cell(2, 4).text = grade7PPA80
table.cell(2, 5).text = grade7PPA81
for row in [0, 2]:  
    cell = table.cell(row, 0)
    for paragraph in cell.paragraphs:
        for run in paragraph.runs:
            run.bold = True
for row in table.rows:
    row.cells[0].width = Pt(150)  # First column narrow
    row.cells[1].width = Pt(60)  # Middle column wide
    row.cells[2].width = Pt(60)
    row.cells[3].width = Pt(60)
    row.cells[4].width = Pt(60)
    row.cells[5].width = Pt(60)
for col_idx in range(6): 
    cell = table.cell(2, col_idx)  
    for paragraph in cell.paragraphs:
        for run in paragraph.runs:
            run.bold = True
background_colors = [
    RGBColor(238, 70, 70),   # Red
    RGBColor(235, 121, 96),  # Orange
    RGBColor(250, 172, 23),  # Yellow
    RGBColor(253, 194, 80),  # Light Yellow
    RGBColor(154, 204, 88)   # Green
]

def rgb_to_hex(rgb_color):
    return f'{rgb_color[0]:02X}{rgb_color[1]:02X}{rgb_color[2]:02X}'
for col_idx in range(1, 6):  
    cell = table.cell(0, col_idx)
    cell_text = cell.text
    cell.text = ""
    run = cell.paragraphs[0].add_run(cell_text)
    hex_color = rgb_to_hex(background_colors[col_idx - 1])
    cell._element.get_or_add_tcPr().append(
        OxmlElement('w:shd', {qn('w:fill'): hex_color})
    )
def set_cell_borders(cell):
    cell_xml = cell._element
    tc_pr = cell_xml.get_or_add_tcPr()
    borders = OxmlElement('w:tcBorders')
    for border_name in ['top', 'left', 'bottom', 'right']:
        border = OxmlElement(f'w:{border_name}')
        border.set(qn('w:val'), 'single')  # Single border
        border.set(qn('w:sz'), '4')  # Border width
        border.set(qn('w:space'), '0')  # Space between borders
        border.set(qn('w:color'), '000000')  # Black color for borders
        borders.append(border)
    tc_pr.append(borders)
for row in table.rows:
    for cell in row.cells:
        set_cell_borders(cell)
doc.save('page1_doc.docx') 
print("Table inserted")

#
from docx import Document
from docx.shared import RGBColor, Pt
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
doc = Document('page1_doc.docx')
para = doc.add_paragraph()
table = doc.add_table(rows=3, cols=6)
table.cell(0, 0).text = 'Grade VIII '
table.cell(0, 1).text = '<= 20'
table.cell(0, 2).text = '21-40 '
table.cell(0, 3).text = '41-60 '
table.cell(0, 4).text = '61-80 '
table.cell(0, 5).text = '> 80 '
table.cell(1, 0).text = 'Initial Assessment '
table.cell(1, 1).text = grade8IA20
table.cell(1, 2).text = grade8IA40
table.cell(1, 3).text = grade8IA60
table.cell(1, 4).text = grade8IA80
table.cell(1, 5).text = grade8IA81
table.cell(2, 0).text = 'Post Program Assessment'
table.cell(2, 1).text = grade8PPA20
table.cell(2, 2).text = grade8PPA40
table.cell(2, 3).text = grade8PPA60
table.cell(2, 4).text = grade8PPA80
table.cell(2, 5).text = grade8PPA81
for row in [0, 2]:  
    cell = table.cell(row, 0)
    for paragraph in cell.paragraphs:
        for run in paragraph.runs:
            run.bold = True
for row in table.rows:
    row.cells[0].width = Pt(150)  # First column narrow
    row.cells[1].width = Pt(60)  # Middle column wide
    row.cells[2].width = Pt(60)
    row.cells[3].width = Pt(60)
    row.cells[4].width = Pt(60)
    row.cells[5].width = Pt(60)
for col_idx in range(6): 
    cell = table.cell(2, col_idx)  
    for paragraph in cell.paragraphs:
        for run in paragraph.runs:
            run.bold = True
background_colors = [
    RGBColor(238, 70, 70),   # Red
    RGBColor(235, 121, 96),  # Orange
    RGBColor(250, 172, 23),  # Yellow
    RGBColor(253, 194, 80),  # Light Yellow
    RGBColor(154, 204, 88)   # Green
]

def rgb_to_hex(rgb_color):
    return f'{rgb_color[0]:02X}{rgb_color[1]:02X}{rgb_color[2]:02X}'
for col_idx in range(1, 6):  
    cell = table.cell(0, col_idx)
    cell_text = cell.text
    cell.text = ""
    run = cell.paragraphs[0].add_run(cell_text)
    hex_color = rgb_to_hex(background_colors[col_idx - 1])
    cell._element.get_or_add_tcPr().append(
        OxmlElement('w:shd', {qn('w:fill'): hex_color})
    )
def set_cell_borders(cell):
    cell_xml = cell._element
    tc_pr = cell_xml.get_or_add_tcPr()
    borders = OxmlElement('w:tcBorders')
    for border_name in ['top', 'left', 'bottom', 'right']:
        border = OxmlElement(f'w:{border_name}')
        border.set(qn('w:val'), 'single')  # Single border
        border.set(qn('w:sz'), '4')  # Border width
        border.set(qn('w:space'), '0')  # Space between borders
        border.set(qn('w:color'), '000000')  # Black color for borders
        borders.append(border)
    tc_pr.append(borders)
for row in table.rows:
    for cell in row.cells:
        set_cell_borders(cell)
doc.save('page1_doc.docx') 
print("Table inserted")

#Topic
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph()
para = doc.add_paragraph('3.3 Highly gifted students - Prodigies - > 80 PPA BSPI: ')
run = para.runs[0]
run.bold = True
run.font.size = Pt(14)
run.font.color.rgb = RGBColor(45, 116, 181)
doc.save('page1_doc.docx')

#Next para
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph('Congratulations to our highly gifted student, the prodigies with PPA BSPI scores exceeding 80, on her promising improvement! Keep up the exceptional work and continue to shine brightly!')  
run = para.runs[0]
run.font.size = Pt(12)
doc.save('page1_doc.docx') 

# TABLE 
from docx import Document
from docx.shared import RGBColor, Pt
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
doc = Document('page1_doc.docx')
table = doc.add_table(rows=3, cols=5)
cell = table.cell(0, 2)
cell.text = '                                 Highly gifted students - Prodigies - > 80 PPA BSPI '
run.bold = True
table.cell(0, 0).merge(table.cell(0, 4))
cell = table.cell(0, 0)
cell.paragraphs[0].alignment = 1  
for run in cell.paragraphs[0].runs:
    run.bold = True
    run.font.size = Pt(14) 
    run.font.color.rgb = RGBColor(0, 0, 0) 
table.cell(1, 0).text = 'S.NO'
table.cell(1, 1).text = 'Student Name'
table.cell(1, 2).text = 'Grade'
table.cell(1, 3).text = 'Section'
table.cell(1, 4).text = 'PPA - BSPI'
table.cell(2, 0).text = '1'
table.cell(2, 1).text = prodigiesname
table.cell(2, 2).text = prodigiesgrade
table.cell(2, 3).text = prodigiessec
table.cell(2, 4).text = prodigiesBSPI
for row in [0, 1]:  
    for cell in table.rows[row].cells:
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                run.bold = True
for row in table.rows:
    row.cells[0].width = Pt(30)  # First column narrow
    row.cells[1].width = Pt(250)  # Middle column wide
    row.cells[2].width = Pt(60)
    row.cells[3].width = Pt(60)
    row.cells[4].width = Pt(300)
background_color = RGBColor(146, 208, 80)
def rgb_to_hex(rgb_color):
    return f'{rgb_color[0]:02X}{rgb_color[1]:02X}{rgb_color[2]:02X}'
hex_color = rgb_to_hex((146, 208, 80))  
for col_idx in range(5):  
    cell = table.cell(0, col_idx)
    cell_text = cell.text
    cell.text = ""
    run = cell.paragraphs[0].add_run(cell_text)
    cell._element.get_or_add_tcPr().append(
        OxmlElement('w:shd', {qn('w:fill'): hex_color})
    )
def set_cell_borders(cell, border_width=4):
    cell_xml = cell._element
    tc_pr = cell_xml.get_or_add_tcPr()
    borders = OxmlElement('w:tcBorders')
    for border_name in ['top', 'left', 'bottom', 'right']:
        border = OxmlElement(f'w:{border_name}')
        border.set(qn('w:val'), 'single')  # Single border style
        border.set(qn('w:sz'), str(border_width))  # Border width (size)
        border.set(qn('w:space'), '0')  # Space between borders
        border.set(qn('w:color'), '000000')  # Black color for borders
        borders.append(border)
    tc_pr.append(borders)
border_width = 6  
for row in table.rows:
    for cell in row.cells:
        set_cell_borders(cell, border_width)
doc.save('page1_doc.docx') 
print("Table inserted")

# Topic
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph()
para = doc.add_paragraph('3.4  Future Achievers - 70-80 PPA BSPI: ')
run = para.runs[0]
run.bold = True
run.font.size = Pt(14)
run.font.color.rgb = RGBColor(45, 116, 181)
doc.save('page1_doc.docx')

#Next para
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph('Best wishes to our future achievers, those with PPA BSPI scores ranging from 70 to 80, for their significant improvement! With further training, they are destined to become the stars of tomorrow. Keep up the great work!')  
run = para.runs[0]
run.font.size = Pt(12)
doc.save('page1_doc.docx') 

#Table
from docx import Document
from docx.shared import RGBColor, Pt
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
doc = Document('page1_doc.docx')
table = doc.add_table(rows=24, cols=5)
cell = table.cell(0, 0)
cell.text = '                                FUTURE ACHIEVERS - 70 to 80 PPA BSPI  '
table.cell(0, 0).merge(table.cell(0, 4))
cell = table.cell(0, 0)
cell.paragraphs[0].alignment = 1 
for run in cell.paragraphs[0].runs:
    run.bold = True
    run.font.size = Pt(16) 
    run.font.color.rgb = RGBColor(0, 0, 0) 
table.cell(1, 0).text = 'S.NO'
table.cell(1, 1).text = 'Student Name'
table.cell(1, 2).text = 'Grade'
table.cell(1, 3).text = 'Section'
table.cell(1, 4).text = 'PPA - BSPI'
data = [
    ('1', FAstud1, FAgrade1, FAsec1, FAppa_bspi),
    ('2', 'NAVYASREE', '3', 'A', '70.4'),
    ('4', 'PAVITHRA', '3', 'A', '70'),
    ('4', 'SHANMUGAPRIYA', '3', 'B', '77.6'),
    ('5', 'TEJASHWIN', '3', 'B', '72.2'),
    ('6', 'THANUSHREE', '3', 'B', '71'),
    ('7', 'SAKTHI KARNIKA', '4', 'A', '73.4'),
    ('8', 'HEMADHARSHINI', '4', 'B', '75.4'),
    ('9', 'DHARNEESH', '4', 'B', '72.8'),
    ('10', 'KESAV', '5', 'A', '79.2'),
    ('11', 'VISHNUVARTHAN', '5', 'A', '70.6'),
    ('12', 'THISANTH', '5', 'B', '75.8'),
    ('13', 'KRISHNA KANNIKA', '5', 'B', '74'),
    ('14', 'AKSHAYA KEERTHI', '6', 'A', '76.2'),
    ('15', 'VIDHARSHANA', '6', 'B', '79.2'),
    ('16', 'JOSHNI SREE', '6', 'B', '76.4'),
    ('17', 'NIVEDHA', '6', 'B', '72'),
    ('18', 'UMMUL AYISHA', '7', 'A', '79'),
    ('19', 'DHAANYA', '7', 'A', '75.6'),
    ('20', 'DEVESH KUMAR', '7', 'A', '73.8'),
    ('21', 'SANJAI', '7', 'A', '73.6'),
    ('22', 'GOPIKA', '7', 'A', '71.6')
]
for i, (sno, name, grade, section, ppa) in enumerate(data, start=2):
    table.cell(i, 0).text = sno
    table.cell(i, 1).text = name
    table.cell(i, 2).text = grade
    table.cell(i, 3).text = section
    table.cell(i, 4).text = ppa
for row in [0, 1]:  
    for cell in table.rows[row].cells:
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                run.bold = True
for row in table.rows:
    row.cells[0].width = Pt(30)  # First column narrow
    row.cells[1].width = Pt(250)  # Middle column wide
    row.cells[2].width = Pt(60)
    row.cells[3].width = Pt(60)
    row.cells[4].width = Pt(300)
background_color = RGBColor(255, 192, 0)
def rgb_to_hex(rgb_color):
    return f'{rgb_color[0]:02X}{rgb_color[1]:02X}{rgb_color[2]:02X}'
hex_color = rgb_to_hex((255, 192, 0))  
for col_idx in range(5):  
    cell = table.cell(0, col_idx)
    cell_text = cell.text
    cell.text = ""
    run = cell.paragraphs[0].add_run(cell_text)
    cell._element.get_or_add_tcPr().append(
        OxmlElement('w:shd', {qn('w:fill'): hex_color})
    )
def set_cell_borders(cell, border_width=4):
    cell_xml = cell._element
    tc_pr = cell_xml.get_or_add_tcPr()
    borders = OxmlElement('w:tcBorders')
    for border_name in ['top', 'left', 'bottom', 'right']:
        border = OxmlElement(f'w:{border_name}')
        border.set(qn('w:val'), 'single')
        border.set(qn('w:sz'), str(border_width))
        border.set(qn('w:space'), '0')
        border.set(qn('w:color'), '000000')
        borders.append(border)
    tc_pr.append(borders)
border_width = 6
for row in table.rows:
    for cell in row.cells:
        set_cell_borders(cell, border_width)
doc.save('page1_doc.docx') 
print("Table inserted")


# Topic
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph('3.5 Growing Stars - <= 20 PPA BSPI:')
run = para.runs[0]
run.bold = True
run.font.size = Pt(14)
run.font.color.rgb = RGBColor(45, 116, 181)
doc.save('page1_doc.docx')

#Next para
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph('These students (<= 20 BSPI) require immediate attention for the improvement. With proper training, they are certain to advance to higher bands like their peers. Wishing them the very best as they embark on their path to success!')  
run = para.runs[0]
run.font.size = Pt(12)
doc.save('page1_doc.docx') 

#Table
from docx import Document
from docx.shared import Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
doc = Document('page1_doc.docx')
para = doc.add_paragraph()
table = doc.add_table(rows=16, cols=5)
cell = table.cell(0, 0)
cell.text = '                               GROWING STARS- <= 20 PPA BSPI   '
table.cell(0, 0).merge(table.cell(0, 4))
cell = table.cell(0, 0)
cell.paragraphs[0].alignment = 1
for run in cell.paragraphs[0].runs:
    run.bold = True
    run.font.size = Pt(14)
    run.font.color.rgb = RGBColor(0, 0, 0)
table.cell(1, 0).text = 'S.NO'
table.cell(1, 1).text = 'Student Name'
table.cell(1, 2).text = 'Grade'
table.cell(1, 3).text = 'Section'
table.cell(1, 4).text = 'PPA - BSPI'
data = [
    ('1', gstars_stud1, gstars_grade1, gstars_sec1, gstars_ppabspi1),
    ('2', 'CHERAN', '4', 'B', '20'),
    ('3', 'MOHAN KUMAR', '5', 'A', '15.6'),
    ('4', 'RAMAVARSHAN', '5', 'A', '19.6'),
    ('5', 'SABARIVASAN', '6', 'B', '14.4'),
    ('6', 'SASHVINTH', '7', 'A', '16.4'),
    ('7', 'MLLER', '8', 'A', '18'),
    ('8', 'SUBASH', '8', 'A', '18.2'),
    ('9', 'PRAJITH', '8', 'A', '18.6'),
    ('10', 'SARVESH VIJAY', '8', 'B', '8'),
    ('11', 'RITHIKA SRI', '8', 'B', '17'),
    ('12', 'PARTHIBAN', '8', 'B', '17.2'),
    ('13', 'KAVIYA BHARATHI', '8', 'B', '17.8'),
    ('14', 'KABIL', '8', 'B', '19.8')
]
for i, (sno, name, grade, section, ppa) in enumerate(data, start=2):
    table.cell(i, 0).text = sno
    table.cell(i, 1).text = name
    table.cell(i, 2).text = grade
    table.cell(i, 3).text = section
    table.cell(i, 4).text = ppa
for row in [0, 1]:  
    for cell in table.rows[row].cells:
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                run.bold = True
for row in table.rows:
    row.cells[0].width = Pt(30)  
    row.cells[1].width = Pt(250)  
    row.cells[2].width = Pt(60)
    row.cells[3].width = Pt(60)
    row.cells[4].width = Pt(300)
background_color = RGBColor(255, 192, 0)
def rgb_to_hex(rgb_color):
    return f'{rgb_color[0]:02X}{rgb_color[1]:02X}{rgb_color[2]:02X}'
hex_color = rgb_to_hex((255, 192, 0))  
for col_idx in range(5):  
    cell = table.cell(0, col_idx)
    cell_text = cell.text
    cell.text = ""
    run = cell.paragraphs[0].add_run(cell_text)
    cell._element.get_or_add_tcPr().append(
        OxmlElement('w:shd', {qn('w:fill'): hex_color})
    )
def set_cell_borders(cell, border_width=4):
    cell_xml = cell._element
    tc_pr = cell_xml.get_or_add_tcPr()
    borders = OxmlElement('w:tcBorders')
    for border_name in ['top', 'left', 'bottom', 'right']:
        border = OxmlElement(f'w:{border_name}')
        border.set(qn('w:val'), 'single')
        border.set(qn('w:sz'), str(border_width))
        border.set(qn('w:space'), '0')
        border.set(qn('w:color'), '000000')
        borders.append(border)
    tc_pr.append(borders)
border_width = 6
for row in table.rows:
    for cell in row.cells:
        set_cell_borders(cell, border_width)
doc.save('page1_doc.docx') 
print("Table inserted")

# Topic
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph('4 Skill Performance – Initial Vs.Post Program Assessment  ')
run = para.runs[0]
run.bold = True
run.font.size = Pt(14)
run.font.color.rgb = RGBColor(45, 116, 181)
doc.save('page1_doc.docx')

#Logo
from docx import Document
from docx.shared import Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
doc = Document('page1_doc.docx')  
para = doc.add_paragraph()
run = para.add_run()
logo_path = r'C:\Users\varsh\OneDrive\Sathyabama\Edsix\New folder\logo4.png'  
run.add_picture(logo_path, width=Inches(6)) 
para.alignment = WD_ALIGN_PARAGRAPH.CENTER
doc.save('page1_doc.docx')   

# Text center
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph('The 5 essential skills that the Program tracks and measures.')
para.alignment = WD_ALIGN_PARAGRAPH.CENTER  
run = para.runs[0]
run.bold = True  
run.font.size = Pt(12)  
run.font.color.rgb = RGBColor(255, 0, 0)  
doc.save('page1_doc.docx') 
print("Text centered")

#
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph("The chart below clearly shows the students' considerable improvement in each skill from the Initial Assessment to the Post Program Assessment.")  
run = para.runs[0]
run.font.size = Pt(12)
doc.save('page1_doc.docx') 

#Graph insertion
import matplotlib.pyplot as plt
import numpy as np
from docx import Document
from docx.shared import Inches
import io
def rgb_to_normalized(rgb):
    return tuple([x / 255.0 for x in rgb])
background_color = rgb_to_normalized((32, 56, 100))  
bar1_color = rgb_to_normalized((197, 90, 17))  
bar2_color = rgb_to_normalized((146, 208, 80)) 
items = ['Linguistics', 'Problem Solving', 'Focus and Attention', 'Visual Processing', 'Memory']
post_scores = [linguisPPA, probsolPPA, focusatPPA, visualpPPA, memoryPPA] 
initial_scores = [linguisIA, probsolIA, focusatIA, visualpIA, memoryIA]  
y = np.arange(len(items))  
height = 0.3
fig, ax = plt.subplots(figsize=(9, 5))
plt.gcf().set_facecolor(background_color)
ax.set_facecolor(background_color)  
gap = 0.02
bar1 = ax.barh(y - height/2 - gap, initial_scores, height, label='Initial Assessment', color=bar1_color)  
bar2 = ax.barh(y + height/2 + gap, post_scores, height, label='Post Program Assessment', color=bar2_color) 
ax.set_title('Skill Growth - Average Skill Scores    Initial vs Post Program Assessment', color='white')
ax.set_yticks(y)
ax.set_yticklabels(items, color='white') 
ax.tick_params(axis='x', colors='white')  
ax.tick_params(axis='y', colors='white')  
ax.legend(facecolor='gray', edgecolor='white', loc='upper right', fontsize=10, framealpha=0.7)  
for i, rect in enumerate(bar1):
    width = rect.get_width()
    ax.text(width, rect.get_y() + rect.get_height() / 2, str(initial_scores[i]), ha='left', va='center', color='white')
for i, rect in enumerate(bar2):
    width = rect.get_width()
    ax.text(width, rect.get_y() + rect.get_height() / 2, str(post_scores[i]), ha='left', va='center', color='white')
ax.grid(True, which='both', axis='x' , linestyle='-', color='black', linewidth=0.6, alpha=0.2)
plt.tight_layout()
img_stream = io.BytesIO()
plt.savefig(img_stream, format='png')
img_stream.seek(0) 
doc = Document('page1_doc.docx')  
doc.add_paragraph("Here is the graph comparing Initial vs Post Program Assessment:")
table = doc.add_table(rows=1, cols=1)
cell = table.cell(0, 0)
cell.paragraphs[0].clear()  
cell.paragraphs[0].add_run().add_picture(img_stream, width=Inches(6)) 
cell.alignment = 1  
doc.save('page1_doc.docx')
img_stream.close() 
print("Graph inserted")

#next highlighted para
from docx import Document
from docx.shared import Pt
doc = Document('page1_doc.docx')
para = doc.add_paragraph("Students have achieved remarkable strides, showcasing a remarkable 49% boost in Memory skills, closely followed by an impressive 32% improvement in Focus and Attention & Linguistics skills.")
run = para.runs[0]
run.font.size = Pt(12)
run.font.highlight_color = 7  
doc.save('page1_doc.docx') 

#
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph('MEMORY')
para.alignment = WD_ALIGN_PARAGRAPH.CENTER  
run = para.runs[0]
run.bold = True  
run.font.size = Pt(18)  
run.font.color.rgb = RGBColor(0, 31, 95) 
run.font.underline = True  
doc.save('page1_doc.docx') 

# 
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph('The table below captures the number of students in each score category/band at two specific points in the program – at the beginning, the')  
run = para.add_run(' IA')
run.bold = True  
para.add_run(', and at the end, the ')
run = para.add_run(' PPA.')
run.bold = True
for run in para.runs:
    run.font.size = Pt(12) 
doc.save('page1_doc.docx') 

#Table
from docx import Document
from docx.shared import Inches, Pt
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
doc = Document('page1_doc.docx')
table = doc.add_table(rows=6, cols=4)
table.cell(0, 0).text = 'Skill Score Range'
table.cell(0, 1).text = 'Description'
table.cell(0, 2).text = 'Number of students in IA'
table.cell(0, 3).text = 'Number of students in PPA'
table.cell(1, 0).text = '<=20 '
table.cell(1, 1).text = 'Rigorous and immediate intervention needed'
table.cell(1, 2).text = memIA20
table.cell(1, 3).text = memPPA20
table.cell(2, 0).text = '21-40'
table.cell(2, 1).text = 'Needs intervention at the earliest '
table.cell(2, 2).text = memIA40
table.cell(2, 3).text = memPPA40
table.cell(3, 0).text = '41-60'
table.cell(3, 1).text = 'Intervention will enhance academic performance'
table.cell(3, 2).text = memIA60
table.cell(3, 3).text = memPPA60
table.cell(4, 0).text = '61-80'
table.cell(4, 1).text = 'Can be groomed to be highly successful'
table.cell(4, 2).text = memIA80
table.cell(4, 3).text = memPPA80
table.cell(5, 0).text = '>80'
table.cell(5, 1).text = 'Prodigy – excellent performance! '
table.cell(5, 2).text = memIA81
table.cell(5, 3).text = memPPA81
for column in table.columns:
    for cell in column.cells:
        cell.width = Inches(1.5) 
for cell in table.rows[0].cells:
    for paragraph in cell.paragraphs:
        if paragraph.runs:  
            for run in paragraph.runs:
                run.bold = True
                run.font.size = Pt(12)
for row in table.rows:
    row.cells[0].width = Pt(70)  # First column narrow
    row.cells[1].width = Pt(250)  # Middle column wide
    row.cells[2].width = Pt(100)
    row.cells[3].width = Pt(100)
for row in table.rows:
    for cell in row.cells:
        cell_xml = cell._element
        tc_pr = cell_xml.get_or_add_tcPr()
        borders = OxmlElement('w:tcBorders')
        for border_name in ['top', 'left', 'bottom', 'right']:
            border = OxmlElement(f'w:{border_name}')
            border.set(qn('w:val'), 'single')  # Solid border
            border.set(qn('w:sz'), '4')  # Border width
            border.set(qn('w:space'), '0')  # No space between cells
            border.set(qn('w:color'), '000000')  # Black color for borders
            borders.append(border)
        tc_pr.append(borders)
row_colors = ['EE4646', 'EB795F', 'FAAC17', 'FDC350', '9ACC58']  
for i in range(6):  # Iterate over all rows (index 0 to 5)
    for j in range(2):  # Apply colors only to the first two columns (index 0 and 1)
        cell = table.cell(i, j)
        if i > 0: 
            cell_xml = cell._element
            tc_pr = cell_xml.get_or_add_tcPr()
            shading = OxmlElement('w:shd')
            shading.set(qn('w:fill'), row_colors[i-1] if i > 0 else 'FFFFFF') 
            tc_pr.append(shading)
para = doc.add_paragraph()
doc.save("page1_doc.docx") 
print("Table inserted")

#Graph insertion
import matplotlib.pyplot as plt
import numpy as np
from docx import Document
from docx.shared import Inches
import io
def rgb_to_normalized(rgb):
    return tuple([x / 255.0 for x in rgb])
background_color = rgb_to_normalized((255, 255, 255))  # White background
bar1_color = rgb_to_normalized((255, 192, 0))  
bar2_color = rgb_to_normalized((146, 208, 80))  
items = ['<=20', '21-40', '41-60', '61-80', '>80']
initial_scores = [memgraIA1, memgraIA2, memgraIA3, memgraIA4, memgraIA5]
post_scores = [memgraPA1, memgraPA2, memgraPA3, memgraPA4, memgraPA5]
x = np.arange(len(items))
width = 0.25
fig, ax = plt.subplots(figsize=(9, 5))
plt.gcf().set_facecolor(background_color)
ax.set_facecolor(background_color)  
gap = 0.02
bar1 = ax.bar(x - width/2 - gap, initial_scores, width, label='Initial Assessment', color=bar1_color)
bar2 = ax.bar(x + width/2 + gap, post_scores, width, label='Post Program Assessment', color=bar2_color)
ax.set_title('Memory - Skill Score Analysis', color='black',fontsize = 18, fontweight = 'bold')
ax.set_xticks(x)
ax.set_xticklabels(items, color='black', fontsize = 14)
ax.tick_params(axis='y', colors='black')
ax.tick_params(axis='x', colors='black')
ax.legend(facecolor='gray', edgecolor='white', loc='upper right', fontsize=12, framealpha=0.6)
for i, rect in enumerate(bar1):
    height = rect.get_height()
    ax.text(rect.get_x() + rect.get_width() / 2, height, str(initial_scores[i]), ha='center', va='bottom', color='black')
for i, rect in enumerate(bar2):
    height = rect.get_height()
    ax.text(rect.get_x() + rect.get_width() / 2, height, str(post_scores[i]), ha='center', va='bottom', color='black')
ax.grid(True, which='both', axis='y' , linestyle='-', color='black', linewidth=0.6, alpha=0.2)
plt.tight_layout()
img_stream = io.BytesIO()
plt.savefig(img_stream, format='png')
img_stream.seek(0)  
doc = Document('page1_doc.docx')
table = doc.add_table(rows=1, cols=1)
cell = table.cell(0, 0)
cell.paragraphs[0].clear()
cell.paragraphs[0].add_run().add_picture(img_stream, width=Inches(6))
cell.alignment = 1  
doc.save('page1_doc.docx')
img_stream.close() 
print("graph inserted")

# para
from docx import Document
from docx.shared import Pt
doc = Document('page1_doc.docx')
para = doc.add_paragraph("At the commencement of the program, majority of students fell within the lower score bands. However, by the program's conclusion, a shift is seen, with a larger ratio of students moving into the higher score ranges. The 8% shift from initial to post assessment in >80 band indicates that in terms of MEMORY, the program has effectively helped a larger number of students in improving their skills.")  
run = para.runs[0]
run.font.size = Pt(12)
para = doc.add_paragraph()
doc.save('page1_doc.docx') 

# topic
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph('VISUAL PROCESSING ')
para.alignment = WD_ALIGN_PARAGRAPH.CENTER  
run = para.runs[0]
run.bold = True  
run.font.size = Pt(18)  
run.font.color.rgb = RGBColor(0, 31, 95) 
run.font.underline = True  
doc.save('page1_doc.docx') 

#
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph('The table below captures the number of students in each score category/band at two specific points in the program – at the beginning, the')  
run = para.add_run(' IA')
run.bold = True  
para.add_run(', and at the end, the ')
run = para.add_run(' PPA.')
run.bold = True
for run in para.runs:
    run.font.size = Pt(12) 
doc.save('page1_doc.docx') 

# table
from docx import Document
from docx.shared import Inches, Pt
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
doc = Document('page1_doc.docx')
table = doc.add_table(rows=6, cols=4)
table.cell(0, 0).text = 'Skill Score Range'
table.cell(0, 1).text = 'Description'
table.cell(0, 2).text = 'Number of students in IA'
table.cell(0, 3).text = 'Number of students in PPA'
table.cell(1, 0).text = '<=20 '
table.cell(1, 1).text = 'Rigorous and immediate intervention needed'
table.cell(1, 2).text =  vispIA20
table.cell(1, 3).text =  vispPA20
table.cell(2, 0).text = '21-40'
table.cell(2, 1).text = 'Needs intervention at the earliest '
table.cell(2, 2).text =  vispIA40
table.cell(2, 3).text =  vispPA40
table.cell(3, 0).text = '41-60'
table.cell(3, 1).text = 'Intervention will enhance academic performance'
table.cell(3, 2).text =  vispIA60
table.cell(3, 3).text =  vispPA60
table.cell(4, 0).text = '61-80'
table.cell(4, 1).text = 'Can be groomed to be successfull'
table.cell(4, 2).text =  vispIA80
table.cell(4, 3).text =  vispPA80
table.cell(5, 0).text = '>80'
table.cell(5, 1).text = 'Prodigy – excellent performance!'
table.cell(5, 2).text =  vispIA81
table.cell(5, 3).text =  vispPA81
for column in table.columns:
    for cell in column.cells:
        cell.width = Inches(1.5) 
for cell in table.rows[0].cells:
    for paragraph in cell.paragraphs:
        if paragraph.runs:  
            for run in paragraph.runs:
                run.bold = True
                run.font.size = Pt(12)
for row in table.rows:
    row.cells[0].width = Pt(70)  
    row.cells[1].width = Pt(250)  
    row.cells[2].width = Pt(100)
    row.cells[3].width = Pt(100)
for row in table.rows:
    for cell in row.cells:
        cell_xml = cell._element
        tc_pr = cell_xml.get_or_add_tcPr()
        borders = OxmlElement('w:tcBorders')
        for border_name in ['top', 'left', 'bottom', 'right']:
            border = OxmlElement(f'w:{border_name}')
            border.set(qn('w:val'), 'single')  # Solid border
            border.set(qn('w:sz'), '4')  # Border width
            border.set(qn('w:space'), '0')  # No space between cells
            border.set(qn('w:color'), '000000')  # Black color for borders
            borders.append(border)
        tc_pr.append(borders)
row_colors = ['EE4646', 'EB795F', 'FAAC17', 'FDC350', '9ACC58']  
for i in range(6):  # Iterate over all rows (index 0 to 5)
    for j in range(2):  # Apply colors only to the first two columns (index 0 and 1)
        cell = table.cell(i, j)
        if i > 0: 
            cell_xml = cell._element
            tc_pr = cell_xml.get_or_add_tcPr()
            shading = OxmlElement('w:shd')
            shading.set(qn('w:fill'), row_colors[i-1] if i > 0 else 'FFFFFF') 
            tc_pr.append(shading)
para = doc.add_paragraph()
doc.save("page1_doc.docx") 
print("Table inserted")

#graph
import matplotlib.pyplot as plt
import numpy as np
from docx import Document
from docx.shared import Inches
import io
def rgb_to_normalized(rgb):
    return tuple([x / 255.0 for x in rgb])
background_color = rgb_to_normalized((255, 255, 255))  # White background
bar1_color = rgb_to_normalized((255, 192, 0))  
bar2_color = rgb_to_normalized((146, 208, 80))  
items = ['<=20', '21-40', '41-60', '61-80', '>80']
initial_scores = [visgraIA1, visgraIA2, visgraIA3, visgraIA4,visgraIA5]
post_scores = [visgraPA1, visgraPA2, visgraPA3, visgraPA4, visgraPA5]
x = np.arange(len(items))
width = 0.25
fig, ax = plt.subplots(figsize=(9, 5))
plt.gcf().set_facecolor(background_color)
ax.set_facecolor(background_color)  
gap = 0.02
bar1 = ax.bar(x - width/2 - gap, initial_scores, width, label='Initial Assessment', color=bar1_color)
bar2 = ax.bar(x + width/2 + gap, post_scores, width, label='Post Program Assessment', color=bar2_color)
ax.set_title('Visual Processing - Skill Score Analysis', color='black',fontsize = 18, fontweight = 'bold')
ax.set_xticks(x)
ax.set_xticklabels(items, color='black', fontsize = 14)
ax.tick_params(axis='y', colors='black')
ax.tick_params(axis='x', colors='black')
ax.legend(facecolor='gray', edgecolor='white', loc='upper right', fontsize=12, framealpha=0.6)
for i, rect in enumerate(bar1):
    height = rect.get_height()
    ax.text(rect.get_x() + rect.get_width() / 2, height, str(initial_scores[i]), ha='center', va='bottom', color='black')
for i, rect in enumerate(bar2):
    height = rect.get_height()
    ax.text(rect.get_x() + rect.get_width() / 2, height, str(post_scores[i]), ha='center', va='bottom', color='black')
ax.grid(True, which='both', axis='y' , linestyle='-', color='black', linewidth=0.6, alpha=0.2)
plt.tight_layout()
img_stream = io.BytesIO()
plt.savefig(img_stream, format='png')
img_stream.seek(0)  
doc = Document('page1_doc.docx')
table = doc.add_table(rows=1, cols=1)
cell = table.cell(0, 0)
cell.paragraphs[0].clear()
cell.paragraphs[0].add_run().add_picture(img_stream, width=Inches(6))
cell.alignment = 1  
doc.save('page1_doc.docx')
img_stream.close() 
print("graph inserted")

#text
from docx import Document
from docx.shared import Pt
doc = Document('page1_doc.docx')
para = doc.add_paragraph("Where VISUAL PROCESSING is concerned, students have been able to move into the top bands with 17% improvement; this is a good development as it is bound to positively impact their thought processing as well.")  
run = para.runs[0]
run.font.size = Pt(12)
para = doc.add_paragraph()
doc.save('page1_doc.docx') 

#Topic
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph('FOCUS AND ATTENTION')
para.alignment = WD_ALIGN_PARAGRAPH.CENTER  
run = para.runs[0]
run.bold = True  
run.font.size = Pt(18)  
run.font.color.rgb = RGBColor(0, 31, 95) 
run.font.underline = True  
doc.save('page1_doc.docx') 

#
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph('The table below captures the number of students in each score category/band at two specific points in the program – at the beginning, the')  
run = para.add_run(' IA')
run.bold = True  
para.add_run(', and at the end, the ')
run = para.add_run(' PPA.')
run.bold = True
for run in para.runs:
    run.font.size = Pt(12) 
doc.save('page1_doc.docx') 

# table
from docx import Document
from docx.shared import Inches, Pt
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
doc = Document('page1_doc.docx')
table = doc.add_table(rows=6, cols=4)
table.cell(0, 0).text = 'Skill Score Range'
table.cell(0, 1).text = 'Description'
table.cell(0, 2).text = 'Number of students in IA'
table.cell(0, 3).text = 'Number of students in PPA'
table.cell(1, 0).text = '<=20 '
table.cell(1, 1).text = 'Rigorous and immediate intervention needed'
table.cell(1, 2).text = focuatIA1
table.cell(1, 3).text = focuatPA1
table.cell(2, 0).text = '21-40'
table.cell(2, 1).text = 'Needs intervention at the earliest '
table.cell(2, 2).text = focuatIA2
table.cell(2, 3).text = focuatPA2
table.cell(3, 0).text = '41-60'
table.cell(3, 1).text = 'Intervention will enhance academic performance'
table.cell(3, 2).text = focuatIA3
table.cell(3, 3).text = focuatPA3
table.cell(4, 0).text = '61-80'
table.cell(4, 1).text = 'Can be groomed to be highly successful'
table.cell(4, 2).text = focuatIA4
table.cell(4, 3).text = focuatPA4
table.cell(5, 0).text = '>80'
table.cell(5, 1).text = 'Prodigy – excellent performance!'
table.cell(5, 2).text = focuatIA5
table.cell(5, 3).text = focuatPA5
for column in table.columns:
    for cell in column.cells:
        cell.width = Inches(1.5) 
for cell in table.rows[0].cells:
    for paragraph in cell.paragraphs:
        if paragraph.runs:  
            for run in paragraph.runs:
                run.bold = True
                run.font.size = Pt(12)
for row in table.rows:
    row.cells[0].width = Pt(70)   
    row.cells[1].width = Pt(250)   
    row.cells[2].width = Pt(100)
    row.cells[3].width = Pt(100)
for row in table.rows:
    for cell in row.cells:
        cell_xml = cell._element
        tc_pr = cell_xml.get_or_add_tcPr()
        borders = OxmlElement('w:tcBorders')
        for border_name in ['top', 'left', 'bottom', 'right']:
            border = OxmlElement(f'w:{border_name}')
            border.set(qn('w:val'), 'single')   
            border.set(qn('w:sz'), '4')   
            border.set(qn('w:space'), '0')   
            border.set(qn('w:color'), '000000')   
            borders.append(border)
        tc_pr.append(borders)
row_colors = ['EE4646', 'EB795F', 'FAAC17', 'FDC350', '9ACC58']  
for i in range(6):   
    for j in range(2):  
        cell = table.cell(i, j)
        if i > 0: 
            cell_xml = cell._element
            tc_pr = cell_xml.get_or_add_tcPr()
            shading = OxmlElement('w:shd')
            shading.set(qn('w:fill'), row_colors[i-1] if i > 0 else 'FFFFFF') 
            tc_pr.append(shading)
para = doc.add_paragraph()
doc.save("page1_doc.docx") 
print("Table inserted")

#graph
import matplotlib.pyplot as plt
import numpy as np
from docx import Document
from docx.shared import Inches
import io
def rgb_to_normalized(rgb):
    return tuple([x / 255.0 for x in rgb])
background_color = rgb_to_normalized((255, 255, 255))  # White background
bar1_color = rgb_to_normalized((255, 192, 0))  
bar2_color = rgb_to_normalized((146, 208, 80))  
items = ['<=20', '21-40', '41-60', '61-80', '>80']
initial_scores = [focgraIA1,focgraIA2, focgraIA3, focgraIA4, focgraIA5]
post_scores = [focgraPA1, focgraPA2, focgraPA3, focgraPA4, focgraPA5]
x = np.arange(len(items))
width = 0.25
fig, ax = plt.subplots(figsize=(9, 5))
plt.gcf().set_facecolor(background_color)
ax.set_facecolor(background_color)  
gap = 0.02
bar1 = ax.bar(x - width/2 - gap, initial_scores, width, label='Initial Assessment', color=bar1_color)
bar2 = ax.bar(x + width/2 + gap, post_scores, width, label='Post Program Assessment', color=bar2_color)
ax.set_title('Focus and Attention - Skill Score Analysis', color='black',fontsize = 18, fontweight = 'bold')
ax.set_xticks(x)
ax.set_xticklabels(items, color='black', fontsize = 14)
ax.tick_params(axis='y', colors='black')
ax.tick_params(axis='x', colors='black')
ax.legend(facecolor='gray', edgecolor='white', loc='upper right', fontsize=12, framealpha=0.6)
for i, rect in enumerate(bar1):
    height = rect.get_height()
    ax.text(rect.get_x() + rect.get_width() / 2, height, str(initial_scores[i]), ha='center', va='bottom', color='black')
for i, rect in enumerate(bar2):
    height = rect.get_height()
    ax.text(rect.get_x() + rect.get_width() / 2, height, str(post_scores[i]), ha='center', va='bottom', color='black')
ax.grid(True, which='both', axis='y' , linestyle='-', color='black', linewidth=0.6, alpha=0.2)
plt.tight_layout()
img_stream = io.BytesIO()
plt.savefig(img_stream, format='png')
img_stream.seek(0)  
doc = Document('page1_doc.docx')
table = doc.add_table(rows=1, cols=1)
cell = table.cell(0, 0)
cell.paragraphs[0].clear()
cell.paragraphs[0].add_run().add_picture(img_stream, width=Inches(6))
cell.alignment = 1  
doc.save('page1_doc.docx')
img_stream.close() 
print("Graph inserted")

#text
from docx import Document
from docx.shared import Pt
doc = Document('page1_doc.docx')
para = doc.add_paragraph("In terms of FOCUS AND ATTENTION, students have successfully advanced into the top band with 26% improvement marking a notable enhancement that is likely to enhance their cognitive processing positively.")  
run = para.runs[0]
run.font.size = Pt(12)
para = doc.add_paragraph()
doc.save('page1_doc.docx') 

#Topic
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph('Problem Solving')
para.alignment = WD_ALIGN_PARAGRAPH.CENTER  
run = para.runs[0]
run.bold = True  
run.font.size = Pt(18)  
run.font.color.rgb = RGBColor(0, 31, 95) 
run.font.underline = True  
doc.save('page1_doc.docx') 

#
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph('The table below captures the number of students in each score category/band at two specific points in the program – at the beginning, the')  
run = para.add_run(' IA')
run.bold = True  
para.add_run(', and at the end, the ')
run = para.add_run(' PPA.')
run.bold = True
for run in para.runs:
    run.font.size = Pt(12) 
doc.save('page1_doc.docx') 

# table
from docx import Document
from docx.shared import Inches, Pt
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
doc = Document('page1_doc.docx')
table = doc.add_table(rows=6, cols=4)
table.cell(0, 0).text = 'Skill Score Range'
table.cell(0, 1).text = 'Description'
table.cell(0, 2).text = 'Number of students in IA'
table.cell(0, 3).text = 'Number of students in PPA'
table.cell(1, 0).text = '<=20 '
table.cell(1, 1).text = 'Rigorous and immediate intervention needed'
table.cell(1, 2).text = prosolIA1
table.cell(1, 3).text = prosolPA1
table.cell(2, 0).text = '21-40'
table.cell(2, 1).text = 'Needs intervention at the earliest '
table.cell(2, 2).text = prosolIA2
table.cell(2, 3).text = prosolPA2
table.cell(3, 0).text = '41-60'
table.cell(3, 1).text = 'Intervention will enhance academic performance'
table.cell(3, 2).text = prosolIA3
table.cell(3, 3).text = prosolPA3
table.cell(4, 0).text = '61-80'
table.cell(4, 1).text = 'Can be groomed to be highly successful'
table.cell(4, 2).text = prosolIA4
table.cell(4, 3).text = prosolPA4
table.cell(5, 0).text = '>80'
table.cell(5, 1).text = 'Prodigy – excellent performance!'
table.cell(5, 2).text = prosolIA5
table.cell(5, 3).text = prosolPA5
for column in table.columns:
    for cell in column.cells:
        cell.width = Inches(1.5) 
for cell in table.rows[0].cells:
    for paragraph in cell.paragraphs:
        if paragraph.runs:  
            for run in paragraph.runs:
                run.bold = True
                run.font.size = Pt(12)
for row in table.rows:
    row.cells[0].width = Pt(70)  # First column narrow
    row.cells[1].width = Pt(250)  # Middle column wide
    row.cells[2].width = Pt(100)
    row.cells[3].width = Pt(100)
for row in table.rows:
    for cell in row.cells:
        cell_xml = cell._element
        tc_pr = cell_xml.get_or_add_tcPr()
        borders = OxmlElement('w:tcBorders')
        for border_name in ['top', 'left', 'bottom', 'right']:
            border = OxmlElement(f'w:{border_name}')
            border.set(qn('w:val'), 'single')  # Solid border
            border.set(qn('w:sz'), '4')  # Border width
            border.set(qn('w:space'), '0')  # No space between cells
            border.set(qn('w:color'), '000000')  # Black color for borders
            borders.append(border)
        tc_pr.append(borders)
row_colors = ['EE4646', 'EB795F', 'FAAC17', 'FDC350', '9ACC58']  
for i in range(6):  # Iterate over all rows (index 0 to 5)
    for j in range(2):  # Apply colors only to the first two columns (index 0 and 1)
        cell = table.cell(i, j)
        if i > 0: 
            cell_xml = cell._element
            tc_pr = cell_xml.get_or_add_tcPr()
            shading = OxmlElement('w:shd')
            shading.set(qn('w:fill'), row_colors[i-1] if i > 0 else 'FFFFFF') 
            tc_pr.append(shading)
para = doc.add_paragraph()
doc.save("page1_doc.docx") 
print("Table inserted")

#graph
import matplotlib.pyplot as plt
import numpy as np
from docx import Document
from docx.shared import Inches
import io
def rgb_to_normalized(rgb):
    return tuple([x / 255.0 for x in rgb])
background_color = rgb_to_normalized((255, 255, 255))  # White background
bar1_color = rgb_to_normalized((255, 192, 0))  
bar2_color = rgb_to_normalized((146, 208, 80))  
items = ['<=20', '21-40', '41-60', '61-80', '>80']
initial_scores = [prograIA1, prograIA2, prograIA3, prograIA4, prograIA5]
post_scores = [prograPA1, prograPA2, prograPA3, prograPA4, prograPA5]
x = np.arange(len(items))
width = 0.25
fig, ax = plt.subplots(figsize=(9, 5))
plt.gcf().set_facecolor(background_color)
ax.set_facecolor(background_color)  
gap = 0.02
bar1 = ax.bar(x - width/2 - gap, initial_scores, width, label='Initial Assessment', color=bar1_color)
bar2 = ax.bar(x + width/2 + gap, post_scores, width, label='Post Program Assessment', color=bar2_color)
ax.set_title('Problem Solving- Skill Score Analysis', color='black',fontsize = 18, fontweight = 'bold')
ax.set_xticks(x)
ax.set_xticklabels(items, color='black', fontsize = 14)
ax.tick_params(axis='y', colors='black')
ax.tick_params(axis='x', colors='black')
ax.legend(facecolor='gray', edgecolor='white', loc='upper right', fontsize=12, framealpha=0.6)
for i, rect in enumerate(bar1):
    height = rect.get_height()
    ax.text(rect.get_x() + rect.get_width() / 2, height, str(initial_scores[i]), ha='center', va='bottom', color='black')
for i, rect in enumerate(bar2):
    height = rect.get_height()
    ax.text(rect.get_x() + rect.get_width() / 2, height, str(post_scores[i]), ha='center', va='bottom', color='black')
ax.grid(True, which='both', axis='y' , linestyle='-', color='black', linewidth=0.6, alpha=0.2)
plt.tight_layout()
img_stream = io.BytesIO()
plt.savefig(img_stream, format='png')
img_stream.seek(0)  
doc = Document('page1_doc.docx')
table = doc.add_table(rows=1, cols=1)
cell = table.cell(0, 0)
cell.paragraphs[0].clear()
cell.paragraphs[0].add_run().add_picture(img_stream, width=Inches(6))
cell.alignment = 1  
doc.save('page1_doc.docx')
img_stream.close() 
print("graph inserted")

#text
from docx import Document
from docx.shared import Pt
doc = Document('page1_doc.docx')
para = doc.add_paragraph("Students have achieved top bands in PROBLEM SOLVING, signifying substantial progress likely to enhance their cognitive processing positively. Since this involves analytical skills and is heavy on thinking out of the box, it is necessary to work on it harder.")  
run = para.runs[0]
run.font.size = Pt(12)
para = doc.add_paragraph()
doc.save('page1_doc.docx') 

#Topic
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph('LINGUISTICS')
para.alignment = WD_ALIGN_PARAGRAPH.CENTER  
run = para.runs[0]
run.bold = True  
run.font.size = Pt(18)  
run.font.color.rgb = RGBColor(0, 31, 95) 
run.font.underline = True  
doc.save('page1_doc.docx') 

#
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph('The table below captures the number of students in each score category/band at two specific points in the program – at the beginning, the')  
run = para.add_run(' IA')
run.bold = True  
para.add_run(', and at the end, the ')
run = para.add_run(' PPA.')
run.bold = True
for run in para.runs:
    run.font.size = Pt(12) 
doc.save('page1_doc.docx') 

# table
from docx import Document
from docx.shared import Inches, Pt
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
doc = Document('page1_doc.docx')
table = doc.add_table(rows=6, cols=4)
table.cell(0, 0).text = 'Skill Score Range'
table.cell(0, 1).text = 'Description'
table.cell(0, 2).text = 'Number of students in IA'
table.cell(0, 3).text = 'Number of students in PPA'
table.cell(1, 0).text = '<=20 '
table.cell(1, 1).text = 'Rigorous and immediate intervention needed'
table.cell(1, 2).text = linguiIA1
table.cell(1, 3).text = linguiPA1
table.cell(2, 0).text = '21-40'
table.cell(2, 1).text = 'Needs intervention at the earliest '
table.cell(2, 2).text = linguiIA2
table.cell(2, 3).text = linguiPA2
table.cell(3, 0).text = '41-60'
table.cell(3, 1).text = 'Intervention will enhance academic performance'
table.cell(3, 2).text = linguiIA3
table.cell(3, 3).text = linguiPA3
table.cell(4, 0).text = '61-80'
table.cell(4, 1).text = 'Can be groomed to be highly successful'
table.cell(4, 2).text = linguiIA4
table.cell(4, 3).text = linguiPA4
table.cell(5, 0).text = '>80'
table.cell(5, 1).text = 'Prodigy – excellent performance!'
table.cell(5, 2).text = linguiIA5
table.cell(5, 3).text = linguiPA5
for column in table.columns:
    for cell in column.cells:
        cell.width = Inches(1.5) 
for cell in table.rows[0].cells:
    for paragraph in cell.paragraphs:
        if paragraph.runs:  
            for run in paragraph.runs:
                run.bold = True
                run.font.size = Pt(12)
for row in table.rows:
    row.cells[0].width = Pt(70)  
    row.cells[1].width = Pt(250)  
    row.cells[2].width = Pt(100)
    row.cells[3].width = Pt(100)
for row in table.rows:
    for cell in row.cells:
        cell_xml = cell._element
        tc_pr = cell_xml.get_or_add_tcPr()
        borders = OxmlElement('w:tcBorders')
        for border_name in ['top', 'left', 'bottom', 'right']:
            border = OxmlElement(f'w:{border_name}')
            border.set(qn('w:val'), 'single')  
            border.set(qn('w:sz'), '4')  
            border.set(qn('w:space'), '0')  
            border.set(qn('w:color'), '000000')  
            borders.append(border)
        tc_pr.append(borders)
row_colors = ['EE4646', 'EB795F', 'FAAC17', 'FDC350', '9ACC58']  
for i in range(6):  
    for j in range(2):  
        cell = table.cell(i, j)
        if i > 0: 
            cell_xml = cell._element
            tc_pr = cell_xml.get_or_add_tcPr()
            shading = OxmlElement('w:shd')
            shading.set(qn('w:fill'), row_colors[i-1] if i > 0 else 'FFFFFF') 
            tc_pr.append(shading)
para = doc.add_paragraph()
doc.save("page1_doc.docx") 
print("Table inserted")

#graph
import matplotlib.pyplot as plt
import numpy as np
from docx import Document
from docx.shared import Inches
import io 
def rgb_to_normalized(rgb):
    return tuple([x / 255.0 for x in rgb])
background_color = rgb_to_normalized((255, 255, 255))  
bar1_color = rgb_to_normalized((255, 192, 0))  
bar2_color = rgb_to_normalized((146, 208, 80))  
items = ['<=20', '21-40', '41-60', '61-80', '>80']
initial_scores = [lingraIA1, lingraIA1, lingraIA3, lingraIA4, lingraIA5]
post_scores = [lingraPA1, lingraPA2, lingraPA3, lingraPA4, lingraPA5]
x = np.arange(len(items))
width = 0.25
fig, ax = plt.subplots(figsize=(9, 5))
plt.gcf().set_facecolor(background_color)
ax.set_facecolor(background_color)  
gap = 0.02
bar1 = ax.bar(x - width/2 - gap, initial_scores, width, label='Initial Assessment', color=bar1_color)
bar2 = ax.bar(x + width/2 + gap, post_scores, width, label='Post Program Assessment', color=bar2_color)
ax.set_title('Linguistics - Skill Score Analysis', color='black',fontsize = 18, fontweight = 'bold')
ax.set_xticks(x)
ax.set_xticklabels(items, color='black', fontsize = 14)
ax.tick_params(axis='y', colors='black')
ax.tick_params(axis='x', colors='black')
ax.legend(facecolor='gray', edgecolor='white', loc='upper right', fontsize=12, framealpha=0.6)
for i, rect in enumerate(bar1):
    height = rect.get_height()
    ax.text(rect.get_x() + rect.get_width() / 2, height, str(initial_scores[i]), ha='center', va='bottom', color='black')
for i, rect in enumerate(bar2):
    height = rect.get_height()
    ax.text(rect.get_x() + rect.get_width() / 2, height, str(post_scores[i]), ha='center', va='bottom', color='black')
ax.grid(True, which='both', axis='y' , linestyle='-', color='black', linewidth=0.6, alpha=0.2)
plt.tight_layout()
img_stream = io.BytesIO()
plt.savefig(img_stream, format='png')
img_stream.seek(0)  
doc = Document('page1_doc.docx')
table = doc.add_table(rows=1, cols=1)
cell = table.cell(0, 0)
cell.paragraphs[0].clear()
cell.paragraphs[0].add_run().add_picture(img_stream, width=Inches(6))
cell.alignment = 1  
doc.save('page1_doc.docx')
img_stream.close() 
print("Graph inserted")

#text
from docx import Document
from docx.shared import Pt
doc = Document('page1_doc.docx')
para = doc.add_paragraph("Recognizing the crucial role of LINGUISTICS in bolstering other learning domains is imperative for its enhancement. While students are performing satisfactorily in this skill, there remains room for improvement.")  
run = para.runs[0]
run.font.size = Pt(12)
para = doc.add_paragraph()
doc.save('page1_doc.docx')

# text topic
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph()
para = doc.add_paragraph('5 Do You Know How Well They Did? ')
run = para.runs[0]
run.bold = True
run.font.size = Pt(14)
run.font.color.rgb = RGBColor(45, 116, 181)
doc.save('page1_doc.docx')

#
from docx import Document
from docx.shared import Pt
doc = Document('page1_doc.docx')
para = doc.add_paragraph("The table below indicates the scores of students from two categories – those who have completed less than eight sessions in CAUP and those who have completed more than eight sessions in CAUP. ")  
para = doc.add_paragraph("The total number of students who have taken ")
run = para.add_run(' IA')
run.bold = True  
para.add_run(' &')
run = para.add_run(' PPA')
run.bold = True
para.add_run(' is ')
run = para.add_run( noofstudentsdoneppa)
run.bold = True
run = para.runs[0]
run.font.size = Pt(12)
para = doc.add_paragraph()
doc.save('page1_doc.docx')

#Table creation
from docx import Document
from docx.shared import Pt, RGBColor
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
doc = Document('page1_doc.docx')
table = doc.add_table(rows=7, cols=7)
headers = ['S.No', 'Grade', 'Total students completed PPA ', 'Number of students who have taken below 8 sessions in CAUP ', 'Average score of PPA taken by students who have completed below 8 sessions in CAUP ', 'Number of students who have taken 8 and more sessions in CAUP ', 'Average score of PPA taken by students who have taken 8 and above session we in CAUP']
rows_data = [
    ['1', 'Grade III', '63', '0', grade3avgscbel8, '63', grade3avgsabove8],
    ['2', 'Grade IV', '58', '0', grade4avgscbel8, '58', grade4avgsabove8],
    ['3', 'Grade V', '69', '0', grade5avgscbel8, '69', grade5avgsabove8],
    ['4', 'Grade VI', '58', '0', grade6avgscbel8, '58', grade6avgsabove8],
    ['5', 'Grade VII', '36', '0', grade7avgscbel8, '36', grade7avgsabove8],
    ['6', 'Grade VIII', '45', '0', grade8avgscbel8, '45', grade8avgsabove8]
]
for col, header in enumerate(headers):
    cell = table.cell(0, col)
    cell.text = header
    for paragraph in cell.paragraphs:
        for run in paragraph.runs:
            run.bold = True
            run.font.size = Pt(14)  
    cell_xml = cell._element
    tc_pr = cell_xml.get_or_add_tcPr()
    shading = OxmlElement('w:shd')  # Create shading element for background color
    shading.set(qn('w:fill'), '92CDEC')  # Set background color (example: light green RGB)
    tc_pr.append(shading)
    cell_text = cell._element
    tc_pr = cell_text.get_or_add_tcPr()
    rotation = OxmlElement('w:textDirection')
    rotation.set(qn('w:val'), 'btLr') 
    tc_pr.append(rotation)
    if col in [0, 2, 3, 5]:  
        cell_width = Inches(1.5)  # Adjust to a smaller width
    else: 
        cell_width = Inches(2.5)  
    tc_pr = cell_xml.get_or_add_tcPr()
    tc_w = OxmlElement('w:tcW')
    tc_w.set(qn('w:w'), str(int(cell_width * 1440)))  # Convert inches to twips (1 inch = 1440 twips)
    tc_w.set(qn('w:type'), 'dxa')  # Type 'dxa' means it's in twips
    tc_pr.append(tc_w)
table.rows[0].height = Inches(2.5) 
for col in range(len(headers)):
    cell = table.cell(0, col)
    cell_xml = cell._element
    tc_pr = cell_xml.get_or_add_tcPr()
    borders = OxmlElement('w:tcBorders')
    for border_name in ['top', 'left', 'bottom', 'right']:
        border = OxmlElement(f'w:{border_name}')
        border.set(qn('w:val'), 'single')
        border.set(qn('w:sz'), str(4))  # Adjust the factor as needed
        border.set(qn('w:space'), '0')  # No space between borders
        border.set(qn('w:color'), '000000')  # Black border color
        borders.append(border)
    tc_pr.append(borders)
for i, row_data in enumerate(rows_data, start=1):
    for j, text in enumerate(row_data):
        cell = table.cell(i, j)
        cell.text = text
        if j in [4, 6]:  
            for paragraph in cell.paragraphs:
                for run in paragraph.runs:
                    run.bold = True
                    run.font.size = Pt(12) 
for row in table.rows:
    for cell in row.cells:
        cell_xml = cell._element
        tc_pr = cell_xml.get_or_add_tcPr()
        borders = OxmlElement('w:tcBorders')
        for border_name in ['top', 'left', 'bottom', 'right']:
            border = OxmlElement(f'w:{border_name}')
            border.set(qn('w:val'), 'single')
            border.set(qn('w:sz'), '4') 
            border.set(qn('w:space'), '0')  
            border.set(qn('w:color'), '000000')  
            borders.append(border)
        tc_pr.append(borders)
doc.save('page1_doc.docx')
print("Table inserted")

#
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph()
para = doc.add_paragraph('It is evident that students who are regular with CAUP sessions and complete all the required/scheduled sessions have a brighter chance of improving their skills.')
run = para.runs[0]
run.bold = True
run.font.size = Pt(14)
run.font.color.rgb = RGBColor(0, 175, 80)
doc.save('page1_doc.docx')

#Logo
from docx import Document
from docx.shared import Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
doc = Document('page1_doc.docx')  
para = doc.add_paragraph()
run = para.add_run()
logo_path = r'C:\Users\varsh\OneDrive\Sathyabama\Edsix\New folder\logo_image.png'  
run.add_picture(logo_path, width=Inches(2)) 
para.alignment = WD_ALIGN_PARAGRAPH.CENTER
doc.save('page1_doc.docx')  

# topic
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph('6 Sub-Skill Score Analysis')
run = para.runs[0]
run.bold = True
run.font.size = Pt(14)
run.font.color.rgb = RGBColor(45, 116, 181)
doc.save('page1_doc.docx')

# text
from docx import Document
from docx.shared import Pt
doc = Document('page1_doc.docx')
para = doc.add_paragraph("The table below shows the average sub skill scores. The scores were taken based on the CAUP sessions played throughout the program.")  
run = para.runs[0]
run.font.size = Pt(12)
para = doc.add_paragraph()
doc.save('page1_doc.docx')

# Graph3 
import matplotlib.pyplot as plt
import numpy as np
from docx import Document
from docx.shared import Inches
import io
def rgb_to_normalized(rgb):
    return tuple([x / 255.0 for x in rgb])
rgb = (146, 208, 80)  
normalized_rgb = rgb_to_normalized(rgb)
categories = ['Contextual Recall', 'Associative Recall', 'Working Memory',  'Spatial Awareness', 'Conservation', 'Creative Thinking-Visualisation',
              'Creative Thinking-Synthesis', 'Sustaining attention', 'Selective attention', 'Divided attention', 'Inductive Reasoning', 'Deductive Reasoning',
              'Classification', 'Distinguishing', 'Pattern Recognition/Sequencing', 'Inferring', 'Prediction and Conclusion', 'Critical Thinking-Visualisation', 
              'Language Processing', 'Assimilation', 'Accomodation']
scores = [graph1, graph2, graph3, graph4, graph5, graph6, graph7, graph8, graph9, graph10, graph11, graph12, graph13, graph14, graph15, graph16, graph17, graph18, graph19, graph20, graph21]
graph_background_rgb = (32, 56, 100)  
axes_background_rgb = (32, 56, 100)  
graph_background = rgb_to_normalized(graph_background_rgb)
axes_background = rgb_to_normalized(axes_background_rgb)
plt.figure(figsize=(9, 6))
plt.gcf().set_facecolor(graph_background)
ax = plt.gca()
ax.set_facecolor(axes_background)
bar_width = 0.4 
bars = plt.bar(categories, scores, color=normalized_rgb, width=bar_width)
plt.title('Sub Skill Average Scores', fontsize=16, fontweight='bold', color='white')
plt.xticks(rotation=45, ha='right', fontsize=10, color='white')
plt.yticks(np.arange(0, 90, 10), color='white')
ax.grid(True, which='both', axis='y', linestyle='-', linewidth=0.5, color='black')
for i, bar in enumerate(bars):
    height = bar.get_height()  
    plt.text(bar.get_x() + bar.get_width() / 2, height + 1, f'{height:.2f}', ha='center', va='bottom', fontsize=10, color='white')
plt.tight_layout()
img_stream = io.BytesIO()
plt.savefig(img_stream, format='png')
img_stream.seek(0)  
doc = Document('page1_doc.docx')
table = doc.add_table(rows=1, cols=1)
cell = table.cell(0, 0)
cell.paragraphs[0].clear() 
cell.paragraphs[0].add_run().add_picture(img_stream, width=Inches(6)) 
doc.save('page1_doc.docx')
img_stream.close()
print("Graph inserted")

# Text
from docx import Document
from docx.shared import Pt
doc = Document('page1_doc.docx')
para = doc.add_paragraph("These scores offer a comprehensive gauge of the participants' proficiency across various subskills, offering valuable insights into both strengths and areas for improvement.")  
para = doc.add_paragraph("By dissecting these scores, we can uncover patterns and trends that enrich our understanding of the participants' skill development journey throughout the CAUP sessions.")
run = para.runs[0]
run.font.size = Pt(12)
para = doc.add_paragraph()
doc.save('page1_doc.docx')

# topic
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph('7 Achievers in PPA 2023-23')
run = para.runs[0]
run.bold = True
run.font.size = Pt(14)
run.font.color.rgb = RGBColor(45, 116, 181)
doc.save('page1_doc.docx')

# logo
from docx import Document
from docx.shared import Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
doc = Document('page1_doc.docx')  
para = doc.add_paragraph()
run = para.add_run()
logo_path = r'C:\Users\varsh\OneDrive\Sathyabama\Edsix\New folder\logo5.png'  
run.add_picture(logo_path, width=Inches(7)) 
para.alignment = WD_ALIGN_PARAGRAPH.CENTER
doc.save('page1_doc.docx')  
print("Logo added")

# topic
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph('7.1 BSPI Toppers by Grade & Section:')
run = para.runs[0]
run.bold = True
run.font.size = Pt(13)
run.font.color.rgb = RGBColor(46, 116, 181)
doc.save('page1_doc.docx')

#
from docx import Document
from docx.shared import Pt
doc = Document('page1_doc.docx')
para = doc.add_paragraph("The table below recognizes the students who have exhibited the best overall performance of Grades ")  
run = para.add_run(' 3,4,5,6,7,8')
run.bold = True  
para.add_run(' during the')
run = para.add_run(' PPA.')
run.bold = True
para = doc.add_paragraph("This has been computed by comparing the BSPI of students within each section of each grade.")
run = para.runs[0]
run.font.size = Pt(12)
doc.save('page1_doc.docx')

# Table
from docx import Document
from docx.shared import RGBColor
from docx.oxml import OxmlElement
doc = Document('page1_doc.docx')
table = doc.add_table(rows=12, cols=4)
background_rgb = RGBColor(255, 192, 0)
text_content = [
    ['Student Name ', 'Grade', 'Section', 'BSPI'],
    ['DHAKSHANA', 'Row 2 Col 2', 'Row 2 Col 3', 'Row 2 Col 4'],
    ['SHANMUGAPRIYA', 'Row 3 Col 2', 'Row 3 Col 3', 'Row 3 Col 4'],
    ['SAKTHI KARNIKA ', 'Row 4 Col 2', 'Row 4 Col 3', 'Row 4 Col 4'],
    ['HEMADHARSHNI', 'Row 5 Col 2', 'Row 5 Col 3', 'Row 5 Col 4'],
    ['KESAV', 'Row 6 Col 2', 'Row 6 Col 3', 'Row 6 Col 4'],
    ['THISANTH', 'Row 7 Col 2', 'Row 7 Col 3', 'Row 7 Col 4'],
    ['AKSHAYA KEERTHI ', 'Row 8 Col 2', 'Row 8 Col 3', 'Row 8 Col 4'],
    ['VIDHARSANA ', 'Row 9 Col 2', 'Row 9 Col 3', 'Row 9 Col 4'],
    ['SAHAANA', 'Row 10 Col 2', 'Row 10 Col 3', 'Row 10 Col 4'],
    ['ROSHNA ', 'Row 11 Col 2', 'Row 11 Col 3', 'Row 11 Col 4'],
    ['KALEESHWARAN', 'Row 12 Col 2', 'Row 12 Col 3', 'Row 12 Col 4']
]
for row_idx in range(12):
    for col_idx in range(4):
        cell = table.cell(row_idx, col_idx)
        cell.text = text_content[row_idx][col_idx]
        if row_idx == 0:
            cell_xml = cell._element
            tc_pr = cell_xml.get_or_add_tcPr()
            shading = OxmlElement('w:shd')
            shading.set(qn('w:fill'), f'{background_rgb[0]:02X}{background_rgb[1]:02X}{background_rgb[2]:02X}')
            tc_pr.append(shading)
            for paragraph in cell.paragraphs:
                for run in paragraph.runs:
                    run.bold = True
for row in table.rows:
    row.cells[0].width = Pt(200)  # First column narrow
    row.cells[1].width = Pt(80)  # Middle column wide
    row.cells[2].width = Pt(80)
    row.cells[3].width = Pt(80)
for row in table.rows:
    for cell in row.cells:
        cell_xml = cell._element
        tc_pr = cell_xml.get_or_add_tcPr()
        borders = OxmlElement('w:tcBorders')
        for border_name in ['top', 'left', 'bottom', 'right']:
            border = OxmlElement(f'w:{border_name}')
            border.set(qn('w:val'), 'single')  # Set border style
            border.set(qn('w:sz'), '4')  # Set border thickness
            border.set(qn('w:space'), '0')  # No space between borders
            border.set(qn('w:color'), '000000')  # Set border color to black
            borders.append(border)
        tc_pr.append(borders)
doc.save("page1_doc.docx")
print("Table inserted")

#
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph('7.2 Skill Toppers by Grade & Section: ')
run = para.runs[0]  
run.bold = True
run.font.size = Pt(13)
run.font.color.rgb = RGBColor(46, 116, 181)
doc.save('page1_doc.docx')

#
from docx import Document
from docx.shared import Pt
doc = Document('page1_doc.docx')
para = doc.add_paragraph("In addition to the BSPI, a cumulative average of scores across five cognitive skills. They have shown proficiency in individual skills of")  
run = para.add_run(' Grades 3,4,5,6,7,8')
run.bold = True
para.add_run(' during the ')
run = para.add_run(' PPA.')
run.bold = True
run = para.runs[0]
run.font.size = Pt(12)
doc.save('page1_doc.docx')

#
from docx import Document
from docx.shared import Pt
doc = Document('page1_doc.docx')
para = doc.add_paragraph()
para = doc.add_paragraph('Memory Toppers')
run = para.runs[0]
run.bold = True
run.font.size = Pt(12)
doc.save('page1_doc.docx')

# Table
from docx import Document
from docx.shared import RGBColor
from docx.oxml import OxmlElement
doc = Document('page1_doc.docx')
table = doc.add_table(rows=12, cols=4)
background_rgb = RGBColor(255, 192, 0)
text_content = [
    ['Student Name ', 'Grade', 'Section', 'BSPI'],
    ['DHAKSHANA', 'Row 2 Col 2', 'Row 2 Col 3', 'Row 2 Col 4'],
    [' ', 'Row 3 Col 2', 'Row 3 Col 3', 'Row 3 Col 4'],
    [' ', 'Row 4 Col 2', 'Row 4 Col 3', 'Row 4 Col 4'],
    [' ', 'Row 5 Col 2', 'Row 5 Col 3', 'Row 5 Col 4'],
    [' ', 'Row 6 Col 2', 'Row 6 Col 3', 'Row 6 Col 4'],
    [' ', 'Row 7 Col 2', 'Row 7 Col 3', 'Row 7 Col 4'],
    [' ', 'Row 8 Col 2', 'Row 8 Col 3', 'Row 8 Col 4'],
    [' ', 'Row 9 Col 2', 'Row 9 Col 3', 'Row 9 Col 4'],
    [' ', 'Row 10 Col 2', 'Row 10 Col 3', 'Row 10 Col 4'],
    [' ', 'Row 11 Col 2', 'Row 11 Col 3', 'Row 11 Col 4'],
    [' ', 'Row 12 Col 2', 'Row 12 Col 3', 'Row 12 Col 4'],
    [' ', 'Row 11 Col 2', 'Row 11 Col 3', 'Row 11 Col 4'],
    [' ', 'Row 11 Col 2', 'Row 11 Col 3', 'Row 11 Col 4'],
    [' ', 'Row 11 Col 2', 'Row 11 Col 3', 'Row 11 Col 4'],
]
for row_idx in range(12):
    for col_idx in range(4):
        cell = table.cell(row_idx, col_idx)
        cell.text = text_content[row_idx][col_idx]
        if row_idx == 0:
            cell_xml = cell._element
            tc_pr = cell_xml.get_or_add_tcPr()
            shading = OxmlElement('w:shd')
            shading.set(qn('w:fill'), f'{background_rgb[0]:02X}{background_rgb[1]:02X}{background_rgb[2]:02X}')
            tc_pr.append(shading)
            for paragraph in cell.paragraphs:
                for run in paragraph.runs:
                    run.bold = True
for row in table.rows:
    row.cells[0].width = Pt(200)  # First column narrow
    row.cells[1].width = Pt(80)  # Middle column wide
    row.cells[2].width = Pt(80)
    row.cells[3].width = Pt(80)
for row in table.rows:
    for cell in row.cells:
        cell_xml = cell._element
        tc_pr = cell_xml.get_or_add_tcPr()
        borders = OxmlElement('w:tcBorders')
        for border_name in ['top', 'left', 'bottom', 'right']:
            border = OxmlElement(f'w:{border_name}')
            border.set(qn('w:val'), 'single')  # Set border style
            border.set(qn('w:sz'), '4')  # Set border thickness
            border.set(qn('w:space'), '0')  # No space between borders
            border.set(qn('w:color'), '000000')  # Set border color to black
            borders.append(border)
        tc_pr.append(borders)
doc.save("page1_doc.docx")
print("Table inserted")

#
from docx import Document
from docx.shared import Pt
doc = Document('page1_doc.docx')
para = doc.add_paragraph()
para = doc.add_paragraph()
para = doc.add_paragraph('Visual Processing Toppers:')
run = para.runs[0]
run.bold = True
run.font.size = Pt(12)
doc.save('page1_doc.docx')

# table
from docx import Document
from docx.shared import RGBColor
from docx.oxml import OxmlElement
doc = Document('page1_doc.docx')
table = doc.add_table(rows=12, cols=4)
background_rgb = RGBColor(255, 192, 0)
text_content = [
    ['Student Name ', 'Grade', 'Section', 'BSPI'],
    ['DHAKSHANA', 'Row 2 Col 2', 'Row 2 Col 3', 'Row 2 Col 4'],
    [' ', 'Row 3 Col 2', 'Row 3 Col 3', 'Row 3 Col 4'],
    [' ', 'Row 4 Col 2', 'Row 4 Col 3', 'Row 4 Col 4'],
    [' ', 'Row 5 Col 2', 'Row 5 Col 3', 'Row 5 Col 4'],
    [' ', 'Row 6 Col 2', 'Row 6 Col 3', 'Row 6 Col 4'],
    [' ', 'Row 7 Col 2', 'Row 7 Col 3', 'Row 7 Col 4'],
    [' ', 'Row 8 Col 2', 'Row 8 Col 3', 'Row 8 Col 4'],
    [' ', 'Row 9 Col 2', 'Row 9 Col 3', 'Row 9 Col 4'],
    [' ', 'Row 10 Col 2', 'Row 10 Col 3', 'Row 10 Col 4'],
    [' ', 'Row 11 Col 2', 'Row 11 Col 3', 'Row 11 Col 4'],
    [' ', 'Row 12 Col 2', 'Row 12 Col 3', 'Row 12 Col 4'],
    [' ', 'Row 11 Col 2', 'Row 11 Col 3', 'Row 11 Col 4'],
    [' ', 'Row 11 Col 2', 'Row 11 Col 3', 'Row 11 Col 4'],
    [' ', 'Row 11 Col 2', 'Row 11 Col 3', 'Row 11 Col 4'],
]
for row_idx in range(12):
    for col_idx in range(4):
        cell = table.cell(row_idx, col_idx)
        cell.text = text_content[row_idx][col_idx]
        if row_idx == 0:
            cell_xml = cell._element
            tc_pr = cell_xml.get_or_add_tcPr()
            shading = OxmlElement('w:shd')
            shading.set(qn('w:fill'), f'{background_rgb[0]:02X}{background_rgb[1]:02X}{background_rgb[2]:02X}')
            tc_pr.append(shading)
            for paragraph in cell.paragraphs:
                for run in paragraph.runs:
                    run.bold = True
for row in table.rows:
    row.cells[0].width = Pt(200)  # First column narrow
    row.cells[1].width = Pt(80)  # Middle column wide
    row.cells[2].width = Pt(80)
    row.cells[3].width = Pt(80)
for row in table.rows:
    for cell in row.cells:
        cell_xml = cell._element
        tc_pr = cell_xml.get_or_add_tcPr()
        borders = OxmlElement('w:tcBorders')
        for border_name in ['top', 'left', 'bottom', 'right']:
            border = OxmlElement(f'w:{border_name}')
            border.set(qn('w:val'), 'single')  # Set border style
            border.set(qn('w:sz'), '4')  # Set border thickness
            border.set(qn('w:space'), '0')  # No space between borders
            border.set(qn('w:color'), '000000')  # Set border color to black
            borders.append(border)
        tc_pr.append(borders)
doc.save("page1_doc.docx")
print("Table inserted")

#
from docx import Document
from docx.shared import Pt
doc = Document('page1_doc.docx')
para = doc.add_paragraph()
para = doc.add_paragraph('Focus and Attention Toppers:')
run = para.runs[0]
run.bold = True
run.font.size = Pt(12)
doc.save('page1_doc.docx')

#Table
from docx import Document
from docx.shared import RGBColor
from docx.oxml import OxmlElement
doc = Document('page1_doc.docx')
table = doc.add_table(rows=12, cols=4)
background_rgb = RGBColor(255, 192, 0)
text_content = [
    ['Student Name ', 'Grade', 'Section', 'BSPI'],
    ['DHAKSHANA', 'Row 2 Col 2', 'Row 2 Col 3', 'Row 2 Col 4'],
    [' ', 'Row 3 Col 2', 'Row 3 Col 3', 'Row 3 Col 4'],
    [' ', 'Row 4 Col 2', 'Row 4 Col 3', 'Row 4 Col 4'],
    [' ', 'Row 5 Col 2', 'Row 5 Col 3', 'Row 5 Col 4'],
    [' ', 'Row 6 Col 2', 'Row 6 Col 3', 'Row 6 Col 4'],
    [' ', 'Row 7 Col 2', 'Row 7 Col 3', 'Row 7 Col 4'],
    [' ', 'Row 8 Col 2', 'Row 8 Col 3', 'Row 8 Col 4'],
    [' ', 'Row 9 Col 2', 'Row 9 Col 3', 'Row 9 Col 4'],
    [' ', 'Row 10 Col 2', 'Row 10 Col 3', 'Row 10 Col 4'],
    [' ', 'Row 11 Col 2', 'Row 11 Col 3', 'Row 11 Col 4'],
    [' ', 'Row 12 Col 2', 'Row 12 Col 3', 'Row 12 Col 4'],
    [' ', 'Row 11 Col 2', 'Row 11 Col 3', 'Row 11 Col 4'],
    [' ', 'Row 11 Col 2', 'Row 11 Col 3', 'Row 11 Col 4'],
    [' ', 'Row 11 Col 2', 'Row 11 Col 3', 'Row 11 Col 4'],
]
for row_idx in range(12):
    for col_idx in range(4):
        cell = table.cell(row_idx, col_idx)
        cell.text = text_content[row_idx][col_idx]
        if row_idx == 0:
            cell_xml = cell._element
            tc_pr = cell_xml.get_or_add_tcPr()
            shading = OxmlElement('w:shd')
            shading.set(qn('w:fill'), f'{background_rgb[0]:02X}{background_rgb[1]:02X}{background_rgb[2]:02X}')
            tc_pr.append(shading)
            for paragraph in cell.paragraphs:
                for run in paragraph.runs:
                    run.bold = True
for row in table.rows:
    row.cells[0].width = Pt(200) 
    row.cells[1].width = Pt(80)  
    row.cells[2].width = Pt(80)
    row.cells[3].width = Pt(80)
for row in table.rows:
    for cell in row.cells:
        cell_xml = cell._element
        tc_pr = cell_xml.get_or_add_tcPr()
        borders = OxmlElement('w:tcBorders')
        for border_name in ['top', 'left', 'bottom', 'right']:
            border = OxmlElement(f'w:{border_name}')
            border.set(qn('w:val'), 'single')  # Set border style
            border.set(qn('w:sz'), '4')  # Set border thickness
            border.set(qn('w:space'), '0')  # No space between borders
            border.set(qn('w:color'), '000000')  # Set border color to black
            borders.append(border)
        tc_pr.append(borders)
doc.save("page1_doc.docx")
print("Table inserted")

# 
from docx import Document
from docx.shared import Pt
doc = Document('page1_doc.docx')
para = doc.add_paragraph()
para = doc.add_paragraph('Problem Solving Toppers')
run = para.runs[0]
run.bold = True
run.font.size = Pt(12)
doc.save('page1_doc.docx')

# Table
from docx import Document
from docx.shared import RGBColor
from docx.oxml import OxmlElement
doc = Document('page1_doc.docx')
table = doc.add_table(rows=12, cols=4)
background_rgb = RGBColor(255, 192, 0)
text_content = [
    ['Student Name ', 'Grade', 'Section', 'BSPI'],
    ['SUBASARATHY', '3', 'A', '78'],
    ['TEJASHWIN', '3', 'B', '92'],
    ['KOWSHICK SIDDARTH ', '4', 'A', '29'],
    ['KIRAN', '4', 'B', '91'],
    ['KESAV', '5', 'A', '99'],
    ['KRISHNA KANNIKA ', '5', 'B', '90'],
    ['KALKI MUTHAMIL', '6', 'A', '85'],
    ['NIVEDHA', '6', 'B', '89'],
    ['AKILESH', '6', 'B', '89'],
    ['SRI DHARSHINI ', '7', 'A', '99'],
    ['GOPIKA', '7', 'A', '90'],
    ['CHANDANA', '7', 'A', '90'],
    ['KARTHICK', '8', 'A', '95'],
    ['KALEESHWARAN', '8', 'B', '99'],
]
for row_idx in range(12):
    for col_idx in range(4):
        cell = table.cell(row_idx, col_idx)
        cell.text = text_content[row_idx][col_idx]
        if row_idx == 0:
            cell_xml = cell._element
            tc_pr = cell_xml.get_or_add_tcPr()
            shading = OxmlElement('w:shd')
            shading.set(qn('w:fill'), f'{background_rgb[0]:02X}{background_rgb[1]:02X}{background_rgb[2]:02X}')
            tc_pr.append(shading)
            for paragraph in cell.paragraphs:
                for run in paragraph.runs:
                    run.bold = True
for row in table.rows:
    row.cells[0].width = Pt(200)  # First column narrow
    row.cells[1].width = Pt(80)  # Middle column wide
    row.cells[2].width = Pt(80)
    row.cells[3].width = Pt(80)
for row in table.rows:
    for cell in row.cells:
        cell_xml = cell._element
        tc_pr = cell_xml.get_or_add_tcPr()
        borders = OxmlElement('w:tcBorders')
        for border_name in ['top', 'left', 'bottom', 'right']:
            border = OxmlElement(f'w:{border_name}')
            border.set(qn('w:val'), 'single')  # Set border style
            border.set(qn('w:sz'), '4')  # Border size
            border.set(qn('w:space'), '0')  # Border space
            border.set(qn('w:color'), '000000')  # Border color (black)
            borders.append(border)  
        tc_pr.append(borders)
doc.save("page1_doc.docx")
print("Table inserted")

#
from docx import Document
from docx.shared import Pt
doc = Document('page1_doc.docx')
para = doc.add_paragraph()
para = doc.add_paragraph('Linguistics Toppers:')
run = para.runs[0]
run.bold = True
run.font.size = Pt(12)
doc.save('page1_doc.docx')

# Table
from docx import Document
from docx.shared import RGBColor
from docx.oxml import OxmlElement
doc = Document('page1_doc.docx')
table = doc.add_table(rows=10, cols=4)
background_rgb = RGBColor(255, 192, 0)
text_content = [
    ['Student Name ', 'Grade', 'Section', 'BSPI'],
    ['VASANTHKUMAR', '3', 'A', '50'],
    ['DHARSHAN', '3', 'B', '50'],
    ['SAKTHI KARNIKA', '4', 'A', '58'],
    ['HEMADHARSHINI', '4', 'B', '50'],
    ['RAHINI', '5', 'A', '67'],
    ['KARTHIK', '5', 'B', '60'],
    ['PRAGATHI', '6', 'A', '70'],
    ['VIDHARSHANA', '6', 'B', '72'],
    ['SAHAANA', '7', 'A', '98'],
]
for row_idx in range(10):
    for col_idx in range(4):
        cell = table.cell(row_idx, col_idx)
        cell.text = text_content[row_idx][col_idx]
        if row_idx == 0:
            cell_xml = cell._element
            tc_pr = cell_xml.get_or_add_tcPr()
            shading = OxmlElement('w:shd')
            shading.set(qn('w:fill'), f'{background_rgb[0]:02X}{background_rgb[1]:02X}{background_rgb[2]:02X}')
            tc_pr.append(shading)
            for paragraph in cell.paragraphs:
                for run in paragraph.runs:
                    run.bold = True
for row in table.rows:
    row.cells[0].width = Pt(200)  
    row.cells[1].width = Pt(80)  
    row.cells[2].width = Pt(80)
    row.cells[3].width = Pt(80)
for row in table.rows:
    for cell in row.cells:
        cell_xml = cell._element
        tc_pr = cell_xml.get_or_add_tcPr()
        borders = OxmlElement('w:tcBorders')
        for border_name in ['top', 'left', 'bottom', 'right']:
            border = OxmlElement(f'w:{border_name}')
            border.set(qn('w:val'), 'single') 
            border.set(qn('w:sz'), '4')  
            border.set(qn('w:space'), '0') 
            border.set(qn('w:color'), '000000')  
            borders.append(border)
        tc_pr.append(borders)
doc.save('page1_doc.docx')
print("Table inserted")

# logo
from docx import Document
from docx.shared import Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
doc = Document('page1_doc.docx')  
para = doc.add_paragraph()
run = para.add_run()
logo_path = r'C:\Users\varsh\OneDrive\Sathyabama\Edsix\New folder\logo6.png'  
run.add_picture(logo_path, width=Inches(7)) 
para.alignment = WD_ALIGN_PARAGRAPH.CENTER
doc.save('page1_doc.docx')  

# text center
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph()
para = doc.add_paragraph("Play is crucial to the healthy development of children's minds. Puzzles and strategy-based games help reinforce critical thinking skills.")
para.alignment = WD_ALIGN_PARAGRAPH.CENTER  
run = para.runs[0]
run.bold = True
run.font.size = Pt(12)  
run.font.color.rgb = RGBColor(164, 164, 164)
doc.save('page1_doc.docx')

#
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph('8 Final Interface')
run = para.runs[0]
run.bold = True
run.font.size = Pt(14)
run.font.color.rgb = RGBColor(46, 116, 181)
doc.save('page1_doc.docx')

#
from docx import Document 
from docx.shared import Pt
doc = Document('page1_doc.docx')
para = doc.add_paragraph("Upon closely looking at the analysis and all the revealed data points, it seems reasonable to conclude that there is a visible development in the performance of each student who has been enrolled in the program. Nevertheless, it's vital to acknowledge the fact that certain skill areas come more naturally to students than others.")
para = doc.add_paragraph("Memory and Linguistics – seem to be the easier zones for students, while Problem Solving & Visual Processing are still a bit difficult to master.")
para = doc.add_paragraph("Specifically, the low scores in Visual processing stand out as a recurring challenge; this necessitates additional support for students to navigate and achieve better proficiency in this specific skill domain. The improvement seen in this skill domain is quite marginal and is a point that needs to be taken note of by the school.")
para = doc.add_paragraph("Overall, there is a lot of scope for improvement in each of the five skill domains. In the current scenario, where the focus is on cognitive upskilling, it is necessary for the school to recognize the connection between a program like SKILLANGELS and the academic performance of every student.")
run = para.runs[0]
run.font.size = Pt(12)
doc.save('page1_doc.docx')

#
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph('9 Next Level Coonsiderations ')
run = para.runs[0]
run.bold = True
run.font.size = Pt(14)
run.font.color.rgb = RGBColor(46, 116, 181)
doc.save('page1_doc.docx')

#
from docx import Document
from docx.shared import Pt
doc = Document('page1_doc.docx')
para = doc.add_paragraph("Though we do agree that every bit of improvement in student performance calls for celebration, it should also help stakeholders be far from complacent about the results achieved. Students' performance at  ")
run = para.add_run( schoolname )
run.bold = True
para.add_run(' on the SKILLANGELS CAUP platform has moved from  ')
run = para.add_run( schoolavgbspi )
run.bold = True
run.font.color.rgb = RGBColor(0, 175, 80)
para.add_run(' While this is good it is certainly not enough!')
para = doc.add_paragraph("The opportunity for improvement in the domains of Problem Solving and Visual Processing highlights areas where teachers and schools can focus their efforts, offering more training to empower students in these skills. ")
para = doc.add_paragraph("Considering the government's prioritization of skill development, it is imperative for every student to actively participate in a platform that guides them in the right direction. The contemporary student needs to focus on practical skills crucial for real-life situations, and this program serves as a vital framework for building the necessary foundation.")
para = doc.add_paragraph("We express strong confidence that the ongoing implementation of SKILLANGELS - CAUP will positively elevate the performance of each student in the years ahead. ")
para = doc.add_paragraph("Thank you for joining us on this impactful journey to empower students with these valuable skills.")
run = para.runs[0]
run.font.size = Pt(12)
doc.save('page1_doc.docx')
print("Text inserted")

#
from docx import Document
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph('10 Other Links:')
run = para.runs[0]
run.bold = True
run.font.size = Pt(14)
run.font.color.rgb = RGBColor(46, 116, 181) 
doc.save('page1_doc.docx')

# LAST TEXT  IN CENTER
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt, RGBColor
doc = Document('page1_doc.docx')
para = doc.add_paragraph("Annexure 1 contains the individual scores of each student.")
para.alignment = WD_ALIGN_PARAGRAPH.CENTER  
run = para.runs[0]
run.bold = True
run.font.size = Pt(14)  
run.font.color.rgb = RGBColor(46, 116, 181) 
doc.save('page1_doc.docx')

#Adding footer text
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.shared import RGBColor 
doc = Document('page1_doc.docx')
section = doc.sections[0]
footer = section.footer
footer_paragraph = footer.paragraphs[0]
footer_paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT 
run = footer_paragraph.add_run(schoolname)
run.bold = True
run = footer_paragraph.add_run('\n')
run.font.color.rgb = RGBColor(0, 0, 0)
run.bold = True
run = footer_paragraph.add_run('Performance Report 2023-24')
run.font.color.rgb = RGBColor(0, 0, 0)
run.bold = True
footer_paragraph2 = footer.add_paragraph()
footer_paragraph2.alignment = WD_ALIGN_PARAGRAPH.RIGHT   
run = footer_paragraph2.add_run('Page | ')
run.font.color.rgb = RGBColor(0, 0, 0)
run.bold = True
field_code = 'PAGE'
run = footer_paragraph2.add_run()
field = OxmlElement('w:fldSimple')
field.set(qn('w:instr'), field_code)
run._r.append(field) 
doc.save('page1_doc.docx')
print("The pages are created sucessfully!!")

